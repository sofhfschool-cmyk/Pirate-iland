// server/database.ts
import { createHash, randomBytes, randomUUID, pbkdf2, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { mkdir } from "node:fs/promises";
import { dirname, resolve } from "node:path";
import { createClient } from "@libsql/client";

// src/lib/types.ts
var levels = [
  "Class VIII",
  "Class IX",
  "Class X",
  "Class XI",
  "Class XII",
  "JEE Main"
];
var totalMarks = (paper) => paper.questions.reduce((n, q) => n + q.marks, 0);
function gradeAttempt(draft, user, finishedAt = Date.now()) {
  const { paper, answers } = draft;
  let score = 0, correct = 0, incorrect = 0, unanswered = 0;
  paper.questions.forEach((q) => {
    if (answers[q.id] === void 0) unanswered++;
    else if (answers[q.id] === q.correct) {
      correct++;
      score += q.marks;
    } else {
      incorrect++;
      score -= paper.negative;
    }
  });
  return {
    id: `result-${crypto.randomUUID()}`,
    userId: user.id,
    student: user.name,
    paperId: paper.id,
    title: paper.title,
    level: paper.level,
    subject: paper.subject,
    questions: paper.questions,
    answers,
    finishedAt,
    elapsed: Math.max(
      0,
      Math.min(
        paper.minutes * 60,
        Math.round((finishedAt - draft.startedAt) / 1e3)
      )
    ),
    negative: paper.negative,
    score: Math.round(score * 100) / 100,
    total: totalMarks(paper),
    correct,
    incorrect,
    unanswered
  };
}

// src/lib/data.ts
var studentDemo = {
  id: "demo-student",
  name: "Aarav Sharma",
  email: "student@pirate.school",
  role: "student",
  level: "Class XII",
  demo: true
};
var adminDemo = {
  id: "demo-admin",
  name: "Meera Patel",
  email: "admin@pirate.school",
  role: "admin",
  level: "Class XII",
  demo: true
};
function numeric(i, text, value, unit, subject, explanation, id) {
  const delta = value < 2 ? 0.2 : Math.max(1, Math.round(Math.abs(value) / 4));
  const correct = (i * 7 + 1) % 4;
  const offsets = i % 3 === 0 ? [1, -1, 2] : i % 3 === 1 ? [-1, 2, -2] : [2, -1, 1];
  const options = offsets.map(
    (n) => `${Number((value + n * delta).toFixed(3))}${unit}`
  );
  options.splice(correct, 0, `${Number(value.toFixed(3))}${unit}`);
  return {
    id: `${id}-${i + 1}`,
    text,
    choices: options,
    correct,
    subject,
    marks: 4,
    explanation
  };
}
function makeQuestion(topic, i, id) {
  const n = i + 2, k = Math.floor(i / 3) + 2;
  const q = (text, value, unit, subject, explanation) => numeric(i, text, value, unit, subject, explanation, id);
  if (topic === "electro") {
    if (i % 3 === 0)
      return q(
        `A charge of $${k}\\,\\mu\\mathrm{C}$ is placed in a uniform electric field of $3\\times10^5\\,\\mathrm{N/C}$. What is the magnitude of the force on the charge?`,
        k * 0.3,
        " N",
        "Physics",
        `Use $F=qE$. Converting the charge to coulombs gives $F=${k}\\times10^{-6}\\times3\\times10^5=${Number((k * 0.3).toFixed(1))}\\,\\mathrm{N}$.`
      );
    if (i % 3 === 1)
      return q(
        `A $${k}\\,\\mu\\mathrm{F}$ capacitor is connected across a $12\\,\\mathrm{V}$ battery. What charge does it store?`,
        k * 12,
        " \u03BCC",
        "Physics",
        `The stored charge is $Q=CV=${k}\\times12=${k * 12}\\,\\mu\\mathrm{C}$.`
      );
    return q(
      `Moving a $${k}\\,\\mathrm{C}$ test charge between two points requires $${k * n}\\,\\mathrm{J}$ of work. Find the magnitude of the potential difference.`,
      n,
      " V",
      "Physics",
      `Potential difference is work per unit charge: $V=W/q=${k * n}/${k}=${n}\\,\\mathrm{V}$.`
    );
  }
  if (topic === "matrices") {
    if (i % 3 === 0)
      return q(
        `Find the determinant of the matrix $A=\\begin{pmatrix}${k} & 1 \\\\ 2 & ${k + 1}\\end{pmatrix}$.`,
        k * (k + 1) - 2,
        "",
        "Mathematics",
        `For a $2\\times2$ matrix, $\\det(A)=ad-bc=${k}(${k + 1})-2=${k * (k + 1) - 2}$.`
      );
    if (i % 3 === 1)
      return q(
        `If $A=\\begin{pmatrix}${n} & 2 \\\\ 0 & ${k}\\end{pmatrix}$, what is the trace of $A$?`,
        n + k,
        "",
        "Mathematics",
        `The trace is the sum of the diagonal elements: $${n}+${k}=${n + k}$.`
      );
    return q(
      `A square matrix $A$ of order 2 has $\\det(A)=${k}$. Find $\\det(3A)$.`,
      9 * k,
      "",
      "Mathematics",
      `For an $n\\times n$ matrix, $\\det(cA)=c^n\\det(A)$. Here $3^2\\times${k}=${9 * k}$.`
    );
  }
  if (topic === "atomic") {
    if (i % 3 === 0)
      return q(
        `An atom has atomic number $${n}$ and mass number $${2 * n + 1}$. How many neutrons does its nucleus contain?`,
        n + 1,
        "",
        "Chemistry",
        `Neutron count is mass number minus atomic number: $${2 * n + 1}-${n}=${n + 1}$.`
      );
    if (i % 3 === 1)
      return q(
        `A sample contains $${k}$ moles of helium. Find its mass, taking the molar mass of helium as $4\\,\\mathrm{g/mol}$.`,
        4 * k,
        " g",
        "Chemistry",
        `Mass equals amount times molar mass: $m=nM=${k}\\times4=${4 * k}\\,\\mathrm{g}$.`
      );
    return q(
      `How many moles are present in $${18 * k}\\,\\mathrm{g}$ of water? Use $M(\\mathrm{H_2O})=18\\,\\mathrm{g/mol}$.`,
      k,
      " mol",
      "Chemistry",
      `Use $n=m/M=${18 * k}/18=${k}\\,\\mathrm{mol}$.`
    );
  }
  if (topic === "force") {
    if (i % 2 === 0)
      return q(
        `A force of $${n * 20}\\,\\mathrm{N}$ acts normally on a surface of area $${n}\\,\\mathrm{m^2}$. Calculate the pressure.`,
        20,
        " Pa",
        "Science",
        `Pressure is force per unit area: $P=F/A=${n * 20}/${n}=20\\,\\mathrm{Pa}$.`
      );
    return q(
      `A box experiences a force of $${n * 5}\\,\\mathrm{N}$ to the right and $${n * 2}\\,\\mathrm{N}$ to the left. Find the magnitude of the resultant force.`,
      n * 3,
      " N",
      "Science",
      `The forces are opposite, so their magnitudes subtract: $${n * 5}-${n * 2}=${n * 3}\\,\\mathrm{N}$.`
    );
  }
  if (topic === "motion") {
    if (i % 2 === 0)
      return q(
        `A cyclist travels $${n * 6}\\,\\mathrm{m}$ in $6\\,\\mathrm{s}$ at constant speed. Find the speed.`,
        n,
        " m/s",
        "Physics",
        `Speed is distance divided by time: $v=${n * 6}/6=${n}\\,\\mathrm{m/s}$.`
      );
    return q(
      `A body starts from rest and accelerates uniformly at $${k}\\,\\mathrm{m/s^2}$ for $4\\,\\mathrm{s}$. What is its final speed?`,
      4 * k,
      " m/s",
      "Physics",
      `From $v=u+at$, we get $v=0+${k}\\times4=${4 * k}\\,\\mathrm{m/s}$.`
    );
  }
  if (topic === "quadratic") {
    if (i % 2 === 0)
      return q(
        `What is the sum of the roots of $x^2-${n + 3}x+${n * 3}=0$?`,
        n + 3,
        "",
        "Mathematics",
        `For $ax^2+bx+c=0$, the sum of the roots is $-b/a=${n + 3}$.`
      );
    return q(
      `Find the larger root of $x^2-${n + 1}x+${n}=0$.`,
      n,
      "",
      "Mathematics",
      `Factor the expression as $(x-1)(x-${n})=0$. The larger root is $${n}$.`
    );
  }
  if (topic === "trig")
    return q(
      `If $\\sin\\theta=\\frac{3}{5}$ and $\\theta$ is acute, find $${n * 5}\\cos\\theta$.`,
      n * 4,
      "",
      "Mathematics",
      `Using $\\cos^2\\theta=1-\\sin^2\\theta$, we get $\\cos\\theta=4/5$. Thus the result is $${n * 5}\\times4/5=${n * 4}$.`
    );
  if (topic === "calculus")
    return q(
      `For $f(x)=${k}x^2+${n}x$, evaluate $f'(2)$.`,
      4 * k + n,
      "",
      "Mathematics",
      `Differentiate term by term: $f'(x)=${2 * k}x+${n}$. At $x=2$, this is $${4 * k + n}$.`
    );
  return q(
    `Solve for $x$: $${k}x+${k + 1}=${k * n + k + 1}$.`,
    n,
    "",
    "Mathematics",
    `Subtract $${k + 1}$ from both sides, then divide by $${k}$ to obtain $x=${n}$.`
  );
}
var defs = [
  [
    "electrostatics",
    "Electrostatics",
    "Charges, electric fields, and potential.",
    "Class XII",
    "Physics",
    45,
    "electro"
  ],
  [
    "matrices",
    "Matrices & Determinants",
    "Matrix operations and their applications.",
    "Class XII",
    "Mathematics",
    60,
    "matrices"
  ],
  [
    "atomic",
    "Atoms & Mole Calculations",
    "Build confidence in the fundamentals.",
    "Class XI",
    "Chemistry",
    40,
    "atomic"
  ],
  [
    "force",
    "Force & Pressure",
    "Explore forces in everyday life.",
    "Class VIII",
    "Science",
    35,
    "force"
  ],
  [
    "motion",
    "Motion & Acceleration",
    "Speed, velocity, and equations of motion.",
    "Class IX",
    "Physics",
    40,
    "motion"
  ],
  [
    "quadratics",
    "Quadratic Equations",
    "Roots, factors, and quadratic expressions.",
    "Class X",
    "Mathematics",
    45,
    "quadratic"
  ],
  [
    "algebra",
    "Linear Equations",
    "Strengthen your algebra fundamentals.",
    "Class VIII",
    "Mathematics",
    30,
    "algebra"
  ],
  [
    "trig",
    "Trigonometric Functions",
    "Identities and trigonometric ratios.",
    "Class XI",
    "Mathematics",
    45,
    "trig"
  ],
  [
    "calculus",
    "Differential Calculus",
    "Derivatives and their applications.",
    "JEE Main",
    "Mathematics",
    50,
    "calculus"
  ]
];
var builtInPapers = defs.map(
  ([id, title, description, level, subject, minutes, topic]) => ({
    id,
    title,
    description,
    level,
    subject,
    minutes,
    negative: 0,
    published: true,
    type: "Chapter test",
    questions: Array.from({ length: 25 }, (_, i) => makeQuestion(topic, i, id))
  })
);
var featuredPaper = {
  id: "jee-mock-01",
  title: "JEE Main Mock Test 01",
  description: "A full-length practice paper in Physics, Chemistry, and Mathematics.",
  level: "JEE Main",
  subject: "Mixed subjects",
  minutes: 180,
  negative: 1,
  published: true,
  type: "Mock test",
  questions: Array.from(
    { length: 75 },
    (_, i) => makeQuestion(
      i < 25 ? i % 2 ? "motion" : "electro" : i < 50 ? "atomic" : i % 2 ? "matrices" : "calculus",
      i,
      "jee-mock-01"
    )
  )
};
builtInPapers.push(featuredPaper);
function demoAttempts() {
  const offsets = [26, 21, 16, 11, 6, 2], counts = [17, 21, 19, 22, 20, 24], papers = [1, 0, 2, 1, 2, 0];
  return offsets.map((days, idx) => {
    const paper = builtInPapers[papers[idx]], finishedAt = Date.now() - days * 864e5, answers = {};
    paper.questions.forEach((q, i) => {
      if (i < counts[idx]) answers[q.id] = q.correct;
      else if (i < 24) answers[q.id] = (q.correct + 1) % 4;
    });
    return {
      ...gradeAttempt(
        {
          userId: studentDemo.id,
          paper,
          startedAt: finishedAt - (22 + idx) * 6e4,
          endsAt: finishedAt,
          current: 24,
          answers,
          flagged: []
        },
        studentDemo,
        finishedAt
      ),
      id: `demo-result-${idx + 1}`
    };
  });
}

// server/database.ts
var hashPassword = promisify(pbkdf2);
var COOKIE = "pirate_database_session";
var lifetime = 30 * 864e5;
var connection;
var RequestError = class extends Error {
  status;
  constructor(message, status = 400) {
    super(message);
    this.status = status;
  }
};
function fail(message, status = 400) {
  throw new RequestError(message, status);
}
var hashToken = (s) => createHash("sha256").update(s).digest("hex");
var encode = JSON.stringify;
var decode = (value) => JSON.parse(String(value));
var profile = (u) => ({ id: u.id, name: u.name, email: u.email, level: u.level, role: u.role, ...u.demo ? { demo: true } : {} });
async function openDatabase() {
  const remote = process.env.TURSO_DATABASE_URL;
  const file = resolve(process.env.SQLITE_PATH || ".data/pi-rate-i-land.sqlite");
  if (!remote) await mkdir(dirname(file), { recursive: true });
  const db = createClient({ url: remote || `file:${file}`, authToken: process.env.TURSO_AUTH_TOKEN });
  await db.batch([
    "CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE, profile TEXT NOT NULL, salt TEXT NOT NULL, hash TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES accounts(id), expires INTEGER NOT NULL)",
    "CREATE INDEX IF NOT EXISTS session_expiry ON sessions(expires)",
    "CREATE TABLE IF NOT EXISTS papers (id TEXT PRIMARY KEY, published INTEGER NOT NULL, position INTEGER NOT NULL, data TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS attempts (id TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES accounts(id), finished INTEGER NOT NULL, data TEXT NOT NULL)",
    "CREATE INDEX IF NOT EXISTS student_history ON attempts(owner, finished)",
    "CREATE TABLE IF NOT EXISTS drafts (owner TEXT PRIMARY KEY REFERENCES accounts(id), data TEXT NOT NULL)",
    "CREATE TABLE IF NOT EXISTS notices (owner TEXT PRIMARY KEY REFERENCES accounts(id), seen INTEGER NOT NULL)",
    "CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY)"
  ], "write");
  if (!(await db.execute("SELECT 1 FROM schema_migrations WHERE version = 1")).rows.length) {
    const seed = [];
    for (const u of [studentDemo, adminDemo]) {
      const salt = randomUUID(), password = u.role === "admin" ? process.env.PIRATE_ADMIN_PASSWORD || "Admin@123" : "Student@123";
      const hash = (await hashPassword(password, salt, 1e5, 32, "sha256")).toString("hex");
      seed.push({ sql: "INSERT OR IGNORE INTO accounts VALUES(?,?,?,?,?)", args: [u.id, u.email, encode(u), salt, hash] });
    }
    builtInPapers.forEach((p, i) => seed.push({ sql: "INSERT OR IGNORE INTO papers VALUES(?,?,?,?)", args: [p.id, Number(p.published), -i, encode(p)] }));
    for (const a of demoAttempts()) seed.push({ sql: "INSERT OR IGNORE INTO attempts VALUES(?,?,?,?)", args: [a.id, a.userId, a.finishedAt, encode(a)] });
    await db.batch([...seed, "INSERT OR IGNORE INTO schema_migrations VALUES(1)"], "write");
  }
  return db;
}
async function database() {
  connection ??= openDatabase().catch((e) => {
    connection = void 0;
    throw e;
  });
  return connection;
}
async function readBody(req) {
  let raw = req.body;
  if (raw === void 0) {
    const chunks = [];
    let length = 0;
    for await (const chunk of req) {
      const b = Buffer.from(chunk);
      length += b.length;
      if (length > 38e5) fail("This paper is too large.", 413);
      chunks.push(b);
    }
    raw = Buffer.concat(chunks).toString("utf8");
  }
  if (typeof raw === "string" || Buffer.isBuffer(raw)) {
    try {
      raw = JSON.parse(String(raw));
    } catch {
      fail("Invalid database request.");
    }
  }
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) fail("Invalid database request.");
  return raw;
}
function validPaper(p) {
  return !!p && typeof p.id === "string" && p.id.length <= 150 && typeof p.title === "string" && !!p.title.trim() && p.title.length <= 90 && levels.includes(p.level) && typeof p.published === "boolean" && Number.isFinite(p.minutes) && p.minutes >= 1 && p.minutes <= 360 && Number.isFinite(p.negative) && p.negative >= 0 && p.negative <= 10 && Array.isArray(p.questions) && p.questions.length > 0 && p.questions.length <= 200 && p.questions.every((q) => q && typeof q.id === "string" && typeof q.text === "string" && Array.isArray(q.choices) && q.choices.length >= 2 && q.choices.length <= 8 && q.choices.every((c) => typeof c === "string") && Number.isInteger(q.correct) && q.correct >= 0 && q.correct < q.choices.length && Number.isFinite(q.marks) && q.marks > 0 && q.marks <= 100);
}
async function snapshot(db, user) {
  if (!user) return { mode: "shared", user: null, papers: [], attempts: [], draft: null, seen: false };
  const [papers, attempts, draft, notice] = await db.batch([
    `SELECT data FROM papers ${user.role === "admin" ? "" : "WHERE published=1"} ORDER BY position DESC`,
    user.role === "admin" ? "SELECT data FROM attempts ORDER BY finished" : { sql: "SELECT data FROM attempts WHERE owner=? ORDER BY finished", args: [user.id] },
    { sql: "SELECT data FROM drafts WHERE owner=?", args: [user.id] },
    { sql: "SELECT seen FROM notices WHERE owner=?", args: [user.id] }
  ], "read");
  return { mode: "shared", user, papers: papers.rows.map((r) => decode(r.data)), attempts: attempts.rows.map((r) => decode(r.data)), draft: draft.rows[0] ? decode(draft.rows[0].data) : null, seen: !!notice.rows[0]?.seen };
}
async function handleDatabase(req, res) {
  res.setHeader("Cache-Control", "no-store, private");
  res.setHeader("Content-Type", "application/json; charset=utf-8");
  res.setHeader("Vary", "Cookie");
  const send = (data) => res.end(encode(data));
  try {
    if (process.env.VERCEL && !process.env.TURSO_DATABASE_URL) {
      send({ mode: "device" });
      return;
    }
    if (req.method !== "GET" && req.method !== "POST") fail("Method not allowed.", 405);
    if (req.method === "POST") {
      if (!req.headers["content-type"]?.startsWith("application/json")) fail("JSON required.", 415);
      if (req.headers.origin && new URL(req.headers.origin).host !== req.headers.host && new URL(req.headers.origin).host !== req.headers["x-forwarded-host"]) fail("Invalid request origin.", 403);
    }
    const db = await database();
    const cmd = req.method === "GET" ? { action: "state" } : await readBody(req);
    const token = (req.headers.cookie || "").split(";").map((s) => s.trim()).find((s) => s.startsWith(COOKIE + "="))?.slice(COOKIE.length + 1);
    const existing = token && token !== "signed-out" ? (await db.execute({ sql: "SELECT a.profile FROM sessions s JOIN accounts a ON s.owner=a.id WHERE s.token=? AND s.expires>?", args: [hashToken(token), Date.now()] })).rows[0] : void 0;
    let user = existing ? decode(existing.profile) : null;
    const cookie = (value) => res.setHeader("Set-Cookie", `${COOKIE}=${value}; Path=/api/database; HttpOnly; SameSite=Lax; Max-Age=${lifetime / 1e3}${process.env.VERCEL || req.headers["x-forwarded-proto"] === "https" ? "; Secure" : ""}`);
    async function signIn(u) {
      const fresh = randomBytes(32).toString("hex");
      await db.batch([{ sql: "DELETE FROM sessions WHERE token=? OR expires<=?", args: [hashToken(token || ""), Date.now()] }, { sql: "INSERT INTO sessions VALUES(?,?,?)", args: [hashToken(fresh), u.id, Date.now() + lifetime] }], "write");
      cookie(fresh);
      user = u;
    }
    if (cmd.action === "state") {
      if (!token) await signIn(studentDemo);
      send(await snapshot(db, user));
      return;
    }
    if (cmd.action === "logout") {
      if (token) await db.execute({ sql: "DELETE FROM sessions WHERE token=?", args: [hashToken(token)] });
      cookie("signed-out");
      send(await snapshot(db, null));
      return;
    }
    if (cmd.action === "demo") {
      if (cmd.role === "admin" && process.env.PIRATE_ADMIN_PASSWORD) fail("Use the administrator password to sign in.", 401);
      await signIn(cmd.role === "admin" ? adminDemo : studentDemo);
      send(await snapshot(db, user));
      return;
    }
    if (cmd.action === "signup" || cmd.action === "login") {
      const email = String(cmd.email || "").trim().toLowerCase(), password = String(cmd.password || "");
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || password.length > 1024) fail("Enter a valid email and password.");
      let row = (await db.execute({ sql: "SELECT * FROM accounts WHERE email=?", args: [email] })).rows[0];
      if (cmd.action === "signup") {
        if (row) fail("This email already has an account. Please sign in.", 409);
        if (password.length < 8 || !cmd.name?.trim() || !cmd.level || !levels.includes(cmd.level)) fail("Enter your name, level, and a password of at least 8 characters.");
        const u = { id: randomUUID(), name: cmd.name.trim().slice(0, 60), email, role: "student", level: cmd.level };
        const salt = randomUUID(), hash = (await hashPassword(password, salt, 1e5, 32, "sha256")).toString("hex");
        await db.execute({ sql: "INSERT INTO accounts VALUES(?,?,?,?,?)", args: [u.id, email, encode(u), salt, hash] });
        await signIn(u);
        send(await snapshot(db, user));
        return;
      }
      const legacy = cmd.legacyAccount;
      if (!row && legacy?.email === email && legacy.role === "student" && cmd.role === "student" && /^[\da-f-]{36}$/i.test(legacy.id) && levels.includes(legacy.level) && typeof legacy.salt === "string" && legacy.salt.length <= 128) {
        const check2 = (await hashPassword(password, legacy.salt, 1e5, 32, "sha256")).toString("hex");
        if (check2 === legacy.hash) {
          const u = profile({ ...legacy, demo: false });
          await db.execute({ sql: "INSERT OR IGNORE INTO accounts VALUES(?,?,?,?,?)", args: [u.id, email, encode(u), legacy.salt, check2] });
          row = (await db.execute({ sql: "SELECT * FROM accounts WHERE email=?", args: [email] })).rows[0];
        }
      }
      const check = await hashPassword(password, String(row?.salt || "missing-account"), 1e5, 32, "sha256");
      if (!row || !timingSafeEqual(check, Buffer.from(String(row.hash), "hex")) || decode(row.profile).role !== cmd.role) fail("The email or password is incorrect for this account type.", 401);
      await signIn(decode(row.profile));
      send(await snapshot(db, user));
      return;
    }
    if (!user) return fail("Your session has expired. Please sign in again.", 401);
    const owner = user.id;
    if (cmd.action === "paper" || cmd.action === "delete-paper") {
      if (user.role !== "admin") fail("Administrator access is required.", 403);
      if (cmd.action === "paper") {
        const p = cmd.paper;
        if (!validPaper(p)) return fail("Invalid question paper.");
        await db.execute({ sql: "INSERT INTO papers VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET published=excluded.published, data=excluded.data", args: [p.id, Number(p.published), Date.now(), encode(p)] });
      } else {
        if (!cmd.id?.startsWith("paper-")) fail("This paper cannot be removed.");
        await db.execute({ sql: "DELETE FROM papers WHERE id=?", args: [cmd.id] });
      }
    } else if (cmd.action === "draft") {
      const d = cmd.draft;
      if (!d || user.role !== "student" || d.userId !== owner || !Number.isFinite(d.startedAt)) return fail("Invalid test session.");
      const old = (await db.execute({ sql: "SELECT data FROM drafts WHERE owner=?", args: [owner] })).rows[0];
      const previous = old ? decode(old.data) : null;
      const record = previous?.startedAt === d.startedAt ? previous.paper : decode((await db.execute({ sql: "SELECT data FROM papers WHERE id=? AND published=1", args: [d.paper.id] })).rows[0]?.data ?? "null");
      if (!record) return fail("This paper is no longer available.", 404);
      const saved = { ...d, paper: record, endsAt: d.startedAt + record.minutes * 6e4 };
      await db.execute({ sql: "INSERT INTO drafts(owner,data) SELECT ?,? WHERE NOT EXISTS(SELECT 1 FROM attempts WHERE id=?) ON CONFLICT(owner) DO UPDATE SET data=excluded.data", args: [owner, encode(saved), `result-${owner}-${d.startedAt}`] });
    } else if (cmd.action === "submit") {
      const tx = await db.transaction("write");
      try {
        const old = (await tx.execute({ sql: "SELECT data FROM attempts WHERE id=? AND owner=?", args: [cmd.id || "", owner] })).rows[0];
        if (old) {
          await tx.commit();
          send({ attempt: decode(old.data) });
          return;
        }
        const row = (await tx.execute({ sql: "SELECT data FROM drafts WHERE owner=?", args: [owner] })).rows[0];
        if (!row || user.role !== "student") fail("No active test was found.", 409);
        const draft = decode(row.data), id = `result-${owner}-${draft.startedAt}`;
        if (cmd.id !== id) fail("This test was replaced by another attempt.", 409);
        const a = { ...gradeAttempt(draft, user, Math.min(Date.now(), draft.endsAt)), id };
        await tx.execute({ sql: "INSERT INTO attempts VALUES(?,?,?,?)", args: [id, owner, a.finishedAt, encode(a)] });
        await tx.execute({ sql: "DELETE FROM drafts WHERE owner=?", args: [owner] });
        await tx.commit();
        send({ attempt: a });
        return;
      } finally {
        tx.close();
      }
    } else if (cmd.action === "seen") {
      await db.execute({ sql: "INSERT OR REPLACE INTO notices VALUES(?,1)", args: [owner] });
    } else if (cmd.action === "migrate") {
      const rows = [];
      for (const a of cmd.attempts || []) if (a.userId === owner && a.id && Number.isFinite(a.finishedAt) && Array.isArray(a.questions)) rows.push({ sql: "INSERT OR IGNORE INTO attempts VALUES(?,?,?,?)", args: [a.id, owner, a.finishedAt, encode(a)] });
      if (cmd.draft?.userId === owner && validPaper(cmd.draft.paper)) rows.push({ sql: "INSERT OR IGNORE INTO drafts VALUES(?,?)", args: [owner, encode(cmd.draft)] });
      if (cmd.seen) rows.push({ sql: "INSERT OR IGNORE INTO notices VALUES(?,1)", args: [owner] });
      if (user.role === "admin") {
        for (const p of cmd.papers || []) if (validPaper(p)) {
          const baseline = builtInPapers.find((b) => b.id === p.id);
          rows.push({ sql: "INSERT INTO papers VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,published=excluded.published WHERE papers.data=?", args: [p.id, Number(p.published), Date.now(), encode(p), baseline ? encode(baseline) : ""] });
        }
      }
      if (rows.length) await db.batch(rows, "write");
    } else return fail("Unknown persistence operation.");
    send({ ok: true });
  } catch (error) {
    res.statusCode = error instanceof RequestError ? error.status : 503;
    if (!(error instanceof RequestError)) console.error("Database request failed:", error instanceof Error ? error.name : "DatabaseError");
    send({ error: error instanceof RequestError ? error.message : "The database could not save or load your data. Please try again." });
  }
}
export {
  handleDatabase
};
