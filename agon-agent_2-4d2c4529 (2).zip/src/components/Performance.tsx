import { useEffect, useId, useMemo, useRef, useState } from "react";
import {
  ArrowUpRight,
  ChartNoAxesCombined,
  ChevronDown,
  TrendingUp,
  TimerReset,
  Trophy,
  ArrowRight,
  TrendingDown,
} from "lucide-react";
import { Link } from "react-router-dom";
import { type Attempt, percent, shortDate } from "../lib/types";
export function TrendChart({
  attempts,
  large = false,
}: {
  attempts: Attempt[];
  large?: boolean;
}) {
  const id = useId().replace(/:/g, ""),
    [hover, setHover] = useState<number | null>(null);
  const chart = useRef<SVGSVGElement>(null);
  const [dimensions, setDimensions] = useState({ width: large ? 650 : 315, height: large ? 195 : 125 });
  const hasData = attempts.length > 0;
  useEffect(() => {
    if (!chart.current) return;
    const observer = new ResizeObserver(([entry]) => {
      const {width, height} = entry.contentRect;
      if (width > 0 && height > 0) setDimensions({width, height});
    });
    observer.observe(chart.current);
    return () => observer.disconnect();
  }, [hasData]);
  const data = [...attempts]
    .sort((a, b) => a.finishedAt - b.finishedAt)
    .slice(-10);
  if (!data.length)
    return (
      <div className="empty-chart">
        <ChartNoAxesCombined size={24} />
        <p>Your first score starts your trend.</p>
      </div>
    );
  const W = dimensions.width,
    H = dimensions.height,
    L = 35,
    R = 12,
    T = 12,
    B = 24,
    values = data.map(percent),
    low = Math.min(50, Math.floor(Math.min(...values) / 25) * 25),
    high = 100;
  const x = (i: number) =>
      L + (W - L - R) * (data.length === 1 ? 0.5 : i / (data.length - 1)),
    y = (v: number) => T + ((high - v) / (high - low)) * (H - T - B);
  const points = data.map((a, i) => [x(i), y(percent(a))]);
  let d = `M${points[0][0]},${points[0][1]}`;
  for (let i = 1; i < points.length; i++) {
    const p = points[i - 1],
      c = points[i],
      mid = (p[0] + c[0]) / 2;
    d += ` C${mid},${p[1]} ${mid},${c[1]} ${c[0]},${c[1]}`;
  }
  const ticks = [100, (100 + low) / 2, low];
  return (
    <svg
      ref={chart}
      className={`trend-chart ${large ? "large" : ""}`}
      viewBox={`0 0 ${W} ${H}`}
      role="img"
      aria-label={`Score trend: ${data.map((a) => `${shortDate(a.finishedAt)} ${percent(a)} percent`).join(", ")}`}
      onMouseLeave={() => setHover(null)}
    >
      <defs>
        <linearGradient id={`grad${id}`} x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#a084f3" stopOpacity=".24" />
          <stop offset="100%" stopColor="#bca6f5" stopOpacity=".025" />
        </linearGradient>
      </defs>
      {ticks.map((t) => (
        <g key={t}>
          <text x="0" y={y(t) + 3.5} className="chart-label">
            {t}%
          </text>
          <line
            x1={L}
            y1={y(t)}
            x2={W - R}
            y2={y(t)}
            stroke="#e6e4ef"
            strokeDasharray="3.5 4"
          />
        </g>
      ))}
      <path
        d={`${d} L${points[points.length - 1][0]},${H - B} L${points[0][0]},${H - B}Z`}
        fill={`url(#grad${id})`}
      />
      <path
        d={d}
        fill="none"
        stroke="#8963df"
        strokeWidth="2.7"
        strokeLinecap="round"
      />
      {data.map((a, i) => (
        <g key={a.id} onMouseEnter={() => setHover(i)}>
          <circle
            cx={x(i)}
            cy={y(percent(a))}
            r={hover === i ? 5 : 3.4}
            fill="white"
            stroke="#8963df"
            strokeWidth="2.2"
          />
          <circle cx={x(i)} cy={y(percent(a))} r="13" fill="transparent" />
          {(data.length <= 6 ||
            i === 0 ||
            i === data.length - 1 ||
            i % 2 === 0) && (
            <text
              className="chart-label date-label"
              x={x(i)}
              y={H - 3}
              textAnchor={
                i === data.length - 1 ? "end" : i === 0 ? "start" : "middle"
              }
            >
              {shortDate(a.finishedAt)}
            </text>
          )}
          <title>
            {a.title}: {percent(a)}%
          </title>
        </g>
      ))}
      {hover !== null && data[hover] && (
        <g>
          <rect
            x={Math.min(W - 44, Math.max(0, x(hover) - 21))}
            y={Math.max(0, y(values[hover]) - 25)}
            width="42"
            height="18"
            rx="5"
            fill="#50406f"
          />
          <text
            fill="white"
            fontSize="10"
            textAnchor="middle"
            x={Math.min(W - 23, Math.max(21, x(hover)))}
            y={Math.max(12, y(values[hover]) - 12)}
          >
            {values[hover]}%
          </text>
        </g>
      )}
    </svg>
  );
}
export function Performance({
  attempts,
  expanded = false,
}: {
  attempts: Attempt[];
  expanded?: boolean;
}) {
  const [period, setPeriod] = useState("30"),
    [now] = useState(() => Date.now());
  const data = useMemo(
    () =>
      attempts
        .filter(
          (a) =>
            period === "all" || a.finishedAt >= now - Number(period) * 86400000,
        )
        .sort((a, b) => a.finishedAt - b.finishedAt),
    [attempts, period, now],
  );
  const avg = data.length
      ? Math.round(data.reduce((s, a) => s + percent(a), 0) / data.length)
      : 0,
    max = data.length ? Math.max(...data.map(percent)) : 0,
    half = Math.floor(data.length / 2),
    change = half
      ? Math.round(
          data.slice(-half).reduce((s, a) => s + percent(a), 0) / half -
            data.slice(0, half).reduce((s, a) => s + percent(a), 0) / half,
        )
      : 0;
  return (
    <section className={`surface performance ${expanded ? "expanded" : ""}`}>
      <div className="performance-head">
        <h2>{expanded ? "Score trend" : "Your performance"}</h2>
        {!expanded && (
          <span className="small-violet-icon">
            <ChartNoAxesCombined size={18} />
          </span>
        )}
      </div>
      <div className="period-filter">
        <span>Score overview</span>
        <label className="mini-select">
          <select
            aria-label="Performance time range"
            value={period}
            onChange={(e) => setPeriod(e.target.value)}
          >
            <option value="30">Last 30 days</option>
            <option value="7">Last 7 days</option>
            <option value="all">All time</option>
          </select>
          <ChevronDown size={12} />
        </label>
      </div>
      <div className="score-row">
        <strong>
          {avg}
          <span>%</span>
        </strong>
        {data.length > 1 && (
          <span
            className={`trend-pill ${change < 0 ? "down" : ""}`}
            title="Change in average score from the first half to the second half of this period"
          >
            {change >= 0 ? (
              <TrendingUp size={13} />
            ) : (
              <TrendingDown size={13} />
            )}{" "}
            {change >= 0 ? "+" : ""}
            {change} pts
          </span>
        )}
      </div>
      <p className="score-caption">Average score</p>
      <TrendChart attempts={data} large={expanded} />
      {!expanded && (
        <>
          <div className="performance-stats">
            <div>
              <span className="stat-icon purple">
                <TimerReset size={17} />
              </span>
              <span>
                <strong>{data.length.toString().padStart(2, "0")}</strong>
                <small>Tests taken</small>
              </span>
            </div>
            <div>
              <span className="stat-icon apricot">
                <Trophy size={17} />
              </span>
              <span>
                <strong>{max}%</strong>
                <small>Best score</small>
              </span>
            </div>
          </div>
          <Link className="analytics-link" to="/analytics">
            View full analytics
            <ArrowUpRight size={15} />
          </Link>
        </>
      )}
    </section>
  );
}
export function RecentResults({ attempts }: { attempts: Attempt[] }) {
  const latest = [...attempts]
    .sort((a, b) => b.finishedAt - a.finishedAt)
    .slice(0, 2);
  return (
    <section className="surface recent-results">
      <div className="section-title">
        <h2>Recent results</h2>
        <Link to="/analytics#history" aria-label="View all results">
          <ArrowRight size={16} />
        </Link>
      </div>
      {latest.length ? (
        latest.map((a) => (
          <Link to={`/results/${a.id}`} className="recent-result" key={a.id}>
            <span className={`result-swatch ${a.subject.toLowerCase()}`}>
              <ChartNoAxesCombined size={17} />
            </span>
            <span>
              <strong>{a.title}</strong>
              <small>
                {shortDate(a.finishedAt)} · {a.level}
              </small>
            </span>
            <b>{percent(a)}%</b>
          </Link>
        ))
      ) : (
        <p className="quiet-copy">Completed tests will appear here.</p>
      )}
    </section>
  );
}
