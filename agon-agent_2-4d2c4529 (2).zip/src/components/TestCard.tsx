import { ArrowRight, Clock3, Files, Award } from "lucide-react";
import { type Paper, totalMarks, levels, subjectClass } from "../lib/types";
import { SubjectArt, SubjectIcon } from "./ui";
export function LevelTabs({
  value,
  onChange,
}: {
  value: string;
  onChange: (s: string) => void;
}) {
  return (
    <div className="level-tabs" role="group" aria-label="Filter tests by class">
      {["All levels", ...levels].map((level) => (
        <button
          key={level}
          className={value === level ? "selected" : ""}
          aria-pressed={value === level}
          onClick={() => onChange(level)}
        >
          {level}
        </button>
      ))}
    </div>
  );
}
export function TestCard({
  paper,
  onStart,
  resume = false,
}: {
  paper: Paper;
  onStart: (p: Paper) => void;
  resume?: boolean;
}) {
  return (
    <article className={`test-card ${subjectClass(paper.subject)}`}>
      <div className="card-cover">
        <div className="cover-grid" />
        <div className="cover-subject">
          <span>
            <SubjectIcon subject={paper.subject} size={23} />
          </span>
          {paper.subject}
        </div>
        <SubjectArt subject={paper.subject} />
      </div>
      <div className="test-card-main">
        <div className="test-type">
          <span>{paper.level}</span>
          <i />
          {paper.type}
        </div>
        <h3>{paper.title}</h3>
        <div className="test-meta">
          <span>
            <Files size={14} />
            {paper.questions.length} questions
          </span>
          <span>
            <Clock3 size={14} />
            {paper.minutes} min
          </span>
        </div>
      </div>
      <div className="test-card-bottom">
        <span>
          <Award size={16} />
          {totalMarks(paper)} marks
        </span>
        <button onClick={() => onStart(paper)}>
          {resume ? "Resume test" : "Start test"}
          <ArrowRight size={15} />
        </button>
      </div>
    </article>
  );
}
