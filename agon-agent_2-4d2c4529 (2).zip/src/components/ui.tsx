import { useEffect, useId, useRef, type ReactNode } from "react";
import {
  X,
  Atom,
  FlaskConical,
  Shapes,
  Leaf,
  Layers3,
  BookOpen,
  ArrowRight,
} from "lucide-react";
import { Link } from "react-router-dom";
import katex from "katex";
import "katex/dist/katex.min.css";
import type { Subject } from "../lib/types";
export function Brand({ compact = false }: { compact?: boolean }) {
  return (
    <span className={`brand ${compact ? "compact" : ""}`}>
      <img src="/favicon.svg" alt="" />
      <span>
        π-rate <b>i-Land</b>
      </span>
    </span>
  );
}
export function SubjectIcon({
  subject,
  size = 20,
}: {
  subject: Subject;
  size?: number;
}) {
  const Icon = {
    Physics: Atom,
    Mathematics: Shapes,
    Chemistry: FlaskConical,
    Science: Leaf,
    "Mixed subjects": Layers3,
  }[subject];
  return <Icon size={size} strokeWidth={1.65} />;
}
export function MathText({ text }: { text: string }) {
  return (
    <span className="math-text">
      {text
        .split(
          /(\$\$[\s\S]*?\$\$|\$[^$\n]+?\$|\\\([\s\S]*?\\\)|\\\[[\s\S]*?\\\])/g,
        )
        .map((p, i) => {
          const block = p.startsWith("$$") || p.startsWith("\\["),
            inline = p.startsWith("$") || p.startsWith("\\(");
          if (block || inline) {
            const cut = block || p.startsWith("\\") ? 2 : 1;
            return (
              <span
                key={i}
                dangerouslySetInnerHTML={{
                  __html: katex.renderToString(p.slice(cut, -cut), {
                    throwOnError: false,
                    displayMode: block,
                    trust: false,
                    strict: "ignore",
                    output: "htmlAndMathml",
                  }),
                }}
              />
            );
          }
          return (
            <span key={i}>{p.replace(/\\%/g, "%").replace(/~/g, " ")}</span>
          );
        })}
    </span>
  );
}
export function Modal({
  title,
  children,
  onClose,
  wide = false,
}: {
  title: string;
  children: ReactNode;
  onClose: () => void;
  wide?: boolean;
}) {
  const ref = useRef<HTMLDivElement>(null),
    titleId = useId(),
    closeRef = useRef(onClose);
  useEffect(() => {
    closeRef.current = onClose;
  }, [onClose]);
  useEffect(() => {
    const old = document.body.style.overflow,
      previous = document.activeElement as HTMLElement;
    document.body.style.overflow = "hidden";
    const panel = ref.current;
    panel?.focus();
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") closeRef.current();
      if (e.key === "Tab" && panel) {
        const nodes = Array.from(
          panel.querySelectorAll<HTMLElement>(
            'button:not(:disabled), a[href], input, select, textarea, [tabindex="0"]',
          ),
        ).filter((n) => n.getClientRects().length > 0);
        if (!nodes.length) return;
        if (
          e.shiftKey &&
          (document.activeElement === nodes[0] ||
            document.activeElement === panel)
        ) {
          e.preventDefault();
          nodes[nodes.length - 1].focus();
        } else if (
          !e.shiftKey &&
          document.activeElement === nodes[nodes.length - 1]
        ) {
          e.preventDefault();
          nodes[0].focus();
        }
      }
    };
    document.addEventListener("keydown", handler);
    return () => {
      document.body.style.overflow = old;
      document.removeEventListener("keydown", handler);
      previous?.focus();
    };
  }, []);
  return (
    <div
      className="modal-backdrop"
      onMouseDown={(e) => {
        if (e.target === e.currentTarget) onClose();
      }}
    >
      <div
        className={`modal ${wide ? "wide" : ""}`}
        role="dialog"
        aria-modal="true"
        aria-labelledby={titleId}
        ref={ref}
        tabIndex={-1}
      >
        <div className="modal-heading">
          <h2 id={titleId}>{title}</h2>
          <button
            className="icon-button"
            aria-label="Close dialog"
            onClick={onClose}
          >
            <X size={20} />
          </button>
        </div>
        {children}
      </div>
    </div>
  );
}
export function EmptyState({
  title,
  detail,
  action,
}: {
  title: string;
  detail: string;
  action?: ReactNode;
}) {
  return (
    <div className="empty-state">
      <span className="empty-icon">
        <BookOpen size={27} />
      </span>
      <h3>{title}</h3>
      <p>{detail}</p>
      {action}
    </div>
  );
}
export function TextLink({
  to,
  children,
}: {
  to: string;
  children: ReactNode;
}) {
  return (
    <Link className="text-link" to={to}>
      {children}
      <ArrowRight size={15} />
    </Link>
  );
}
export function PageIntro({
  eyebrow,
  title,
  description,
  aside,
}: {
  eyebrow: string;
  title: string;
  description: string;
  aside?: ReactNode;
}) {
  return (
    <div className="page-intro">
      <div>
        <div className="eyebrow">
          <i />
          {eyebrow}
        </div>
        <h1>{title}</h1>
        <p>{description}</p>
      </div>
      {aside}
    </div>
  );
}
export function SubjectArt({ subject }: { subject: Subject }) {
  return (
    <svg
      className="subject-art"
      viewBox="0 0 170 90"
      fill="none"
      aria-hidden="true"
    >
      <g
        stroke="currentColor"
        strokeWidth="1.2"
        strokeLinecap="round"
        strokeLinejoin="round"
      >
        {subject === "Physics" ? (
          <>
            <g transform="translate(107 47) rotate(-16)">
              <ellipse rx="48" ry="16" />
              <ellipse rx="48" ry="16" transform="rotate(60)" />
              <ellipse rx="48" ry="16" transform="rotate(-60)" />
              <circle r="5" fill="currentColor" fillOpacity=".28" />
              <circle cx="44" cy="-6" r="3.5" fill="currentColor" />
              <circle cx="-31" cy="-27" r="3" fill="currentColor" />
            </g>
            <path d="m24 23 4-5 2 5m-12 44 6-4 6 4" opacity=".5" />
          </>
        ) : subject === "Mathematics" ? (
          <>
            <path
              d="M44 72 121 10l25 62Z"
              fill="currentColor"
              fillOpacity=".05"
            />
            <path d="M62 66 117 21l18 45Z" />
            <path d="m56 65 3 5m4-11 3 5m5-11 3 5m5-12 3 5m5-12 3 5m4-12 3 5m5-12 3 5" />
            <circle cx="46" cy="20" r="12" />
            <path d="M32 20h28m-14-14v28m80 42 28-57m-2 2 3-4v5" />
          </>
        ) : subject === "Chemistry" ? (
          <>
            <path d="M86 10h26m-21 0v28L65 73q-4 7 4 7h62q8 0 4-7l-27-35V10" />
            <path
              d="M79 55q15-7 39 0l15 21H68Z"
              fill="currentColor"
              fillOpacity=".08"
            />
            <circle cx="97" cy="64" r="3" />
            <circle cx="108" cy="54" r="2" />
            <circle cx="91" cy="25" r="2" />
            <path d="m29 29 12-8 12 8v13l-12 8-12-8z" />
          </>
        ) : (
          <>
            <path d="M42 75 95 22l37 53Z" />
            <circle cx="108" cy="28" r="18" />
            <path d="m86 77 51-54m-78-8 8 2m-4-6 1 10" />
          </>
        )}
      </g>
    </svg>
  );
}
