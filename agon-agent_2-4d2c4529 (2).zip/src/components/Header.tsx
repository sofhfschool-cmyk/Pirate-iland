import { useEffect, useRef, useState } from "react";
import { Link, NavLink } from "react-router-dom";
import {
  Bell,
  BookOpen,
  ChartNoAxesCombined,
  ChevronDown,
  LayoutGrid,
  LogOut,
  ShieldCheck,
  UserRound,
  ArrowUpRight,
  CheckCheck,
  GraduationCap,
  ListChecks,
  X,
} from "lucide-react";
import { Brand } from "./ui";
import { initials, type User } from "../lib/types";
import { markRead, read } from "../lib/storage";
export function Header({
  user,
  onLogout,
}: {
  user: User;
  onLogout: () => void;
}) {
  const [menu, setMenu] = useState<"account" | "notifications" | null>(null),
    [seen, setSeen] = useState(() => read(`notices:${user.id}`, false));
  const bar = useRef<HTMLElement>(null);
  useEffect(() => {
    function close(e: MouseEvent) {
      if (
        !bar.current || !e.composedPath().includes(bar.current) ||
        (e.target instanceof Element && e.target.closest("a"))
      )
        setMenu(null);
    }
    function escape(e: KeyboardEvent) {
      if (e.key === "Escape") setMenu(null);
    }
    document.addEventListener("click", close);
    document.addEventListener("keydown", escape);
    return () => {
      document.removeEventListener("click", close);
      document.removeEventListener("keydown", escape);
    };
  }, []);
  const admin = user.role === "admin",
    nav = admin
      ? [
          { to: "/admin", label: "Overview", icon: LayoutGrid },
          { to: "/admin/papers", label: "Question papers", icon: BookOpen },
          { to: "/admin/results", label: "Student results", icon: ListChecks },
        ]
      : [
          { to: "/", label: "Dashboard", icon: LayoutGrid },
          { to: "/library", label: "Test library", icon: BookOpen },
          {
            to: "/analytics",
            label: "My analytics",
            icon: ChartNoAxesCombined,
          },
        ];
  return (
    <header className="site-header" ref={bar}>
      <div className="header-inner">
        <Link
          to={admin ? "/admin" : "/"}
          className="brand-link"
          aria-label="π-rate i-Land home"
        >
          <Brand />
        </Link>
        <nav className="main-nav" aria-label="Main navigation">
          {nav.map(({ to, label, icon: Icon }) => (
            <NavLink
              key={to}
              to={to}
              end
              className={({ isActive }) =>
                `nav-item ${isActive ? "active" : ""}`
              }
            >
              <Icon size={17} />
              <span>{label}</span>
            </NavLink>
          ))}
        </nav>
        <div className="header-actions">
          <div className="menu-anchor">
            <button
              className={`bell-button ${menu === "notifications" ? "open" : ""}`}
              aria-label="Notifications"
              aria-expanded={menu === "notifications"}
              onClick={() =>
                setMenu(menu === "notifications" ? null : "notifications")
              }
            >
              <Bell size={20} />
              {!seen && <i />}
            </button>
            {menu === "notifications" && (
              <div className="dropdown notices">
                <div className="dropdown-title">
                  <h3>Notifications</h3>
                  <button
                    className="icon-button"
                    aria-label="Close notifications"
                    onClick={() => setMenu(null)}
                  >
                    <X size={16} />
                  </button>
                </div>
                {seen ? (
                  <div className="notice-empty">
                    <CheckCheck size={25} />
                    <p>You're all caught up.</p>
                  </div>
                ) : (
                  <>
                    <Link
                      className="notice-item"
                      to={admin ? "/admin/papers" : "/library"}
                    >
                      <span className="icon-tile violet">
                        <GraduationCap size={21} />
                      </span>
                      <div>
                        <strong>
                          {admin
                            ? "Your workspace is ready"
                            : "Your practice library is ready"}
                        </strong>
                        <p>
                          {admin
                            ? "Manage papers, or upload your first LaTeX test."
                            : "Explore chapter tests and your featured JEE mock."}
                        </p>
                      </div>
                    </Link>
                    <button
                      className="mark-read"
                      onClick={async () => {
                        try { await markRead(); setSeen(true); } catch { window.dispatchEvent(new CustomEvent('database-error', { detail: 'The notification change could not be saved. Please try again.' })); }
                      }}
                    >
                      <CheckCheck size={14} />
                      Mark all as read
                    </button>
                  </>
                )}
              </div>
            )}
          </div>
          <div className="header-separator" />
          <div className="menu-anchor">
            <button
              className="profile-button"
              onClick={() => setMenu(menu === "account" ? null : "account")}
              aria-expanded={menu === "account"}
              aria-label="Open account menu"
            >
              <span className="avatar">{initials(user.name)}</span>
              <span className="profile-copy">
                <strong>{user.name}</strong>
                <small>
                  {admin ? "Administrator" : `Student · ${user.level}`}
                </small>
              </span>
              <ChevronDown size={15} className="profile-caret" />
            </button>
            {menu === "account" && (
              <div className="dropdown account-menu">
                <div className="account-info">
                  <strong>{user.name}</strong>
                  <span>{user.email}</span>
                  {user.demo && <em>Demo workspace</em>}
                </div>
                <Link to="/login?role=student">
                  <UserRound size={16} />
                  Student login
                  <ArrowUpRight size={13} />
                </Link>
                <Link to="/login?role=admin">
                  <ShieldCheck size={16} />
                  Admin login
                  <ArrowUpRight size={13} />
                </Link>
                <button
                  onClick={() => {
                    setMenu(null);
                    onLogout();
                  }}
                >
                  <LogOut size={16} />
                  Sign out
                </button>
              </div>
            )}
          </div>
        </div>
      </div>
    </header>
  );
}
export function Footer({ admin = false }: { admin?: boolean }) {
  return (
    <footer className="site-footer">
      <div>
        <span className="footer-pi">π</span>
        <span>π-rate i-Land</span>
        <i />A space to learn, practice, and grow.
      </div>
      <Link to={`/login?role=${admin ? "student" : "admin"}`}>
        <ShieldCheck size={14} />
        {admin ? "Student login" : "Admin login"}
        <ArrowUpRight size={12} />
      </Link>
    </footer>
  );
}
