import { useCallback, useEffect, useRef, useState, useSyncExternalStore } from "react";
import {
  Navigate,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from "react-router-dom";
import { CheckCircle2, X } from "lucide-react";
import { Header, Footer } from "./components/Header";
import { Dashboard } from "./pages/Dashboard";
import { Library } from "./pages/Library";
import { Analytics } from "./pages/Analytics";
import { Admin } from "./pages/Admin";
import { Auth } from "./pages/Auth";
import { Exam, Result, StartDialog } from "./pages/Exam";
import {
  subscribe, getSnapshot, persistDraft, persistPaper, signOut, submitAttempt,
} from "./lib/storage";
import {
  type Attempt,
  type Draft,
  type Paper,
  type User,
} from "./lib/types";
function ResultRoute({ attempts, user }: { attempts: Attempt[]; user: User }) {
  const { id } = useParams(),
    a = attempts.find(
      (a) => a.id === id && (user.role === "admin" || a.userId === user.id),
    );
  return a ? (
    <Result attempt={a} user={user} />
  ) : (
    <Navigate
      to={user.role === "admin" ? "/admin/results" : "/analytics"}
      replace
    />
  );
}
export function Workspace() {
  const { user, papers, attempts, draft } = useSyncExternalStore(subscribe, getSnapshot);
  const [launch, setLaunch] = useState<Paper | null>(null),
    [toast, setToast] = useState("");
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null),
    submitting = useRef(false),
    nav = useNavigate(),
    loc = useLocation();
  const notify = useCallback((message: string) => {
    setToast(message);
    if (timer.current) clearTimeout(timer.current);
    timer.current = setTimeout(() => setToast(""), 4200);
  }, []);
  useEffect(() => {
    window.scrollTo(0, 0);
    if (loc.hash === "#history")
      setTimeout(
        () =>
          document
            .getElementById("history")
            ?.scrollIntoView({ behavior: "smooth" }),
        100,
      );
  }, [loc.pathname, loc.hash]);
  useEffect(
    () => () => {
      if (timer.current) clearTimeout(timer.current);
    },
    [],
  );
  useEffect(() => {
    const report = (e: Event) => notify((e as CustomEvent<string>).detail);
    window.addEventListener("database-error", report);
    return () => window.removeEventListener("database-error", report);
  }, [notify]);
  const loginUser = (u: User) => {
    setLaunch(null);
    nav(u.role === "admin" ? "/admin" : "/");
    notify(
      `Welcome${u.demo ? " to the demo workspace" : ` back, ${u.name.split(" ")[0]}`}.`,
    );
  };
  const logout = async () => {
    try { await signOut(); } catch { notify("Unable to sign out. Please try again."); return; }
    setLaunch(null);
    nav("/login");
    notify("You have signed out.");
  };
  const saveDraft = async (d: Draft) => {
    try { await persistDraft(d); return true; } catch { notify("Your change could not be saved. Please try again."); return false; }
  };
  const onStart = (p: Paper) => {
    if (draft?.paper.id === p.id) {
      nav("/exam");
      return;
    }
    setLaunch(p);
  };
  const begin = async () => {
    if (!user || !launch) return;
    const now = Date.now();
    submitting.current = false;
    const saved = await saveDraft({
      userId: user.id,
      paper: launch,
      startedAt: now,
      endsAt: now + launch.minutes * 60000,
      current: 0,
      answers: {},
      flagged: [],
    });
    if (!saved) return;
    setLaunch(null);
    nav("/exam");
  };
  const finish = useCallback(async () => {
    if (!draft || !user || submitting.current) return;
    submitting.current = true;
    try {
      const result = await submitAttempt(draft, user);
      setLaunch(null);
      nav(`/results/${result.id}`);
      notify("Test submitted. Your marks are ready.");
    } catch {
      notify(
        "The database could not submit this test. Your progress is saved; please try again.",
      );
    } finally {
      submitting.current = false;
    }
  }, [draft, user, nav, notify]);
  useEffect(() => {
    if (!draft || !user || loc.pathname === "/exam") return;
    const expiry = setTimeout(finish, Math.max(0, draft.endsAt - Date.now()));
    return () => clearTimeout(expiry);
  }, [draft, user, finish, loc.pathname]);
  const savePaper = async (p: Paper) => {
    try { await persistPaper(p); return true; } catch { notify("The paper could not be saved. Please try again."); return false; }
  };
  const deletePaper = async (id: string) => {
    try { await persistPaper(id); return true; } catch { notify("The paper could not be deleted. Please try again."); return false; }
  };
  const admin = user?.role === "admin",
    authPage = loc.pathname === "/login",
    isExam = loc.pathname === "/exam" && !!draft,
    ownAttempts = attempts.filter((a) => a.userId === user?.id);
  return (
    <>
      {!authPage && user && !isExam && <Header user={user} onLogout={logout} />}
      <Routes>
        <Route
          path="/login"
          element={<Auth key={loc.search} current={user} onLogin={loginUser} />}
        />
        {!user ? (
          <Route path="*" element={<Navigate to="/login" replace />} />
        ) : (
          <>
            <Route
              path="/"
              element={
                admin ? (
                  <Navigate to="/admin" replace />
                ) : (
                  <Dashboard
                    user={user}
                    papers={papers}
                    attempts={ownAttempts}
                    draft={draft}
                    onStart={onStart}
                  />
                )
              }
            />
            <Route
              path="/library"
              element={
                admin ? (
                  <Navigate to="/admin/papers" replace />
                ) : (
                  <Library papers={papers} draft={draft} onStart={onStart} />
                )
              }
            />
            <Route
              path="/analytics"
              element={
                admin ? (
                  <Navigate to="/admin/results" replace />
                ) : (
                  <Analytics attempts={ownAttempts} />
                )
              }
            />
            <Route
              path="/admin/*"
              element={
                admin ? (
                  <Admin
                    papers={papers}
                    attempts={attempts}
                    user={user}
                    onSave={savePaper}
                    onDelete={deletePaper}
                    notify={notify}
                  />
                ) : (
                  <Navigate to="/login?role=admin" replace />
                )
              }
            />
            <Route
              path="/exam"
              element={
                !admin && draft ? (
                  <Exam
                    draft={draft}
                    onChange={saveDraft}
                    onSubmit={finish}
                    onExit={() => {
                      nav("/");
                      notify(
                        "Progress saved. Your test timer is still running.",
                      );
                    }}
                  />
                ) : (
                  <Navigate to={ownAttempts.length ? `/results/${ownAttempts[ownAttempts.length - 1].id}` : "/"} replace />
                )
              }
            />
            <Route
              path="/results/:id"
              element={<ResultRoute user={user} attempts={attempts} />}
            />
            <Route
              path="*"
              element={<Navigate to={admin ? "/admin" : "/"} replace />}
            />
          </>
        )}
      </Routes>
      {!authPage && user && !isExam && (
        <div className="page-container footer-wrap">
          <Footer admin={admin} />
        </div>
      )}
      {launch && (
        <StartDialog
          paper={launch}
          draft={draft}
          onClose={() => setLaunch(null)}
          onBegin={begin}
        />
      )}{" "}
      {toast && (
        <div className="toast" role="status">
          <CheckCircle2 size={18} />
          <span>{toast}</span>
          <button
            aria-label="Dismiss notification"
            onClick={() => setToast("")}
          >
            <X size={14} />
          </button>
        </div>
      )}
    </>
  );
}
