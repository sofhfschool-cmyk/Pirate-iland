import { useEffect, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  Bookmark,
  Check,
  CheckCheck,
  CircleCheck,
  Clock3,
  Flag,
  GraduationCap,
  ListChecks,
  LogOut,
  RotateCcw,
  ShieldCheck,
  Timer,
  X,
  Award,
  Files,
  AlertCircle,
} from "lucide-react";
import { Link } from "react-router-dom";
import {
  type Draft,
  type Paper,
  type User,
  type Attempt,
  totalMarks,
  percent,
  shortDate,
  subjectClass,
} from "../lib/types";
import { Brand, MathText, Modal, SubjectIcon } from "../components/ui";
export function StartDialog({
  paper,
  draft,
  onClose,
  onBegin,
}: {
  paper: Paper;
  draft: Draft | null;
  onClose: () => void;
  onBegin: () => void;
}) {
  return (
    <Modal title="Your test briefing" onClose={onClose}>
      <div className="launch-paper">
        <span className={`subject-tile large ${subjectClass(paper.subject)}`}>
          <SubjectIcon subject={paper.subject} size={26} />
        </span>
        <span className="soft-label">
          {paper.level} · {paper.type}
        </span>
        <h3>{paper.title}</h3>
        <p>{paper.description}</p>
      </div>
      <div className="briefing-stats">
        <div>
          <Files size={18} />
          <strong>{paper.questions.length}</strong>
          <span>Questions</span>
        </div>
        <div>
          <Clock3 size={18} />
          <strong>{paper.minutes} min</strong>
          <span>Time limit</span>
        </div>
        <div>
          <Award size={18} />
          <strong>{totalMarks(paper)}</strong>
          <span>Total marks</span>
        </div>
      </div>
      <h4 className="mini-heading">Before you begin</h4>
      <ul className="instruction-list">
        <li>
          <Check size={15} />
          <span>
            Choose one answer for each question. You can change it before
            submitting.
          </span>
        </li>
        <li>
          <Check size={15} />
          <span>
            {paper.negative
              ? `${paper.negative} mark${paper.negative === 1 ? " is" : "s are"} deducted for each incorrect answer. Unanswered questions score zero.`
              : "No negative marking. Unanswered questions score zero."}
          </span>
        </li>
        <li>
          <Check size={15} />
          <span>
            Your answers are saved automatically. The test submits when the
            timer reaches zero.
          </span>
        </li>
      </ul>
      {draft && (
        <div className="warning-note">
          <AlertCircle size={17} />
          <span>
            Starting this paper will replace your unfinished{" "}
            <strong>{draft.paper.title}</strong> attempt.{" "}
            <Link to="/exam" onClick={onClose}>
              Resume it instead
            </Link>
            .
          </span>
        </div>
      )}
      <div className="modal-actions">
        <button className="secondary-button" onClick={onClose}>
          Not now
        </button>
        <button className="primary-button" onClick={onBegin}>
          Begin test
          <ArrowRight size={15} />
        </button>
      </div>
    </Modal>
  );
}
function formatTime(s: number) {
  return `${Math.floor(s / 3600)
    .toString()
    .padStart(2, "0")}:${Math.floor((s % 3600) / 60)
    .toString()
    .padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
}
export function Exam({
  draft,
  onChange,
  onSubmit,
  onExit,
}: {
  draft: Draft;
  onChange: (d: Draft) => void;
  onSubmit: () => void;
  onExit: () => void;
}) {
  const [remaining, setRemaining] = useState(() =>
      Math.max(0, Math.ceil((draft.endsAt - Date.now()) / 1000)),
    ),
    [confirm, setConfirm] = useState<"submit" | "exit" | null>(null),
    submitRef = useRef(onSubmit),
    expired = useRef(false);
  useEffect(() => {
    submitRef.current = onSubmit;
  }, [onSubmit]);
  useEffect(() => {
    const tick = () => {
      const n = Math.max(0, Math.ceil((draft.endsAt - Date.now()) / 1000));
      setRemaining(n);
      if (!n && !expired.current) {
        expired.current = true;
        submitRef.current();
      }
    };
    tick();
    const t = setInterval(tick, 500);
    return () => clearInterval(t);
  }, [draft.endsAt]);
  const p = draft.paper,
    q = p.questions[draft.current],
    selected = draft.answers[q.id],
    flagged = draft.flagged.includes(q.id),
    answered = Object.keys(draft.answers).length;
  function setIndex(i: number) {
    onChange({
      ...draft,
      current: Math.max(0, Math.min(p.questions.length - 1, i)),
    });
  }
  function clear() {
    const a = { ...draft.answers };
    delete a[q.id];
    onChange({ ...draft, answers: a });
  }
  return (
    <div className="exam-page">
      <header className="exam-header">
        <div>
          <Brand />
          <span className="exam-header-label">Test workspace</span>
        </div>
        <div>
          <span className="autosaved">
            <CheckCheck size={15} />
            Autosaved
          </span>
          <button
            className="secondary-button"
            onClick={() => setConfirm("exit")}
          >
            <LogOut size={14} />
            Save & exit
          </button>
        </div>
      </header>
      <main className="page-container">
        <div className="page-intro">
          <div>
            <div className="eyebrow">
              <i />
              TEST IN PROGRESS
            </div>
            <h1>{p.title}</h1>
            <p>
              {p.level} · {p.subject} · {p.questions.length} questions
            </p>
          </div>
          <div className={`exam-timer ${remaining < 300 ? "urgent" : ""}`}>
            <Timer size={22} />
            <div>
              <small>Time remaining</small>
              <strong>{formatTime(remaining)}</strong>
            </div>
          </div>
        </div>
        <div className="exam-layout">
          <section className="surface question-panel">
            <div className="question-heading">
              <span>
                Question{" "}
                <strong>{String(draft.current + 1).padStart(2, "0")}</strong>{" "}
                <small>/ {p.questions.length}</small>
              </span>
              <div>
                <em className="positive-mark">+{q.marks}</em>
                {p.negative > 0 && (
                  <em className="negative-mark">−{p.negative}</em>
                )}
              </div>
            </div>
            <div className="question-content">
              <span className={`subject-text ${subjectClass(q.subject)}`}>
                <SubjectIcon subject={q.subject} size={15} />
                {q.subject}
              </span>
              <h2>
                <MathText text={q.text} />
              </h2>
              <div
                className="answer-options"
                role="radiogroup"
                aria-label="Answer choices"
              >
                {q.choices.map((c, i) => (
                  <button
                    key={`${q.id}-${i}`}
                    role="radio"
                    aria-checked={selected === i}
                    className={`answer-option ${selected === i ? "selected" : ""}`}
                    onClick={() =>
                      onChange({
                        ...draft,
                        answers: { ...draft.answers, [q.id]: i },
                      })
                    }
                  >
                    <span className="choice-letter">
                      {String.fromCharCode(65 + i)}
                    </span>
                    <MathText text={c} />
                    {selected === i && (
                      <CircleCheck size={18} className="option-check" />
                    )}
                  </button>
                ))}
              </div>
              <div className="question-tools">
                <button
                  className={flagged ? "flagged" : ""}
                  onClick={() =>
                    onChange({
                      ...draft,
                      flagged: flagged
                        ? draft.flagged.filter((id) => id !== q.id)
                        : [...draft.flagged, q.id],
                    })
                  }
                >
                  <Bookmark
                    size={15}
                    fill={flagged ? "currentColor" : "none"}
                  />
                  {flagged ? "Marked for review" : "Mark for review"}
                </button>
                <button disabled={selected === undefined} onClick={clear}>
                  <RotateCcw size={14} />
                  Clear answer
                </button>
              </div>
            </div>
            <div className="question-navigation">
              <button
                className="secondary-button"
                disabled={draft.current === 0}
                onClick={() => setIndex(draft.current - 1)}
              >
                <ArrowLeft size={15} />
                Previous
              </button>
              {draft.current === p.questions.length - 1 ? (
                <button
                  className="primary-button"
                  onClick={() => setConfirm("submit")}
                >
                  Review & submit
                  <ArrowRight size={15} />
                </button>
              ) : (
                <button
                  className="primary-button"
                  onClick={() => setIndex(draft.current + 1)}
                >
                  Save & next
                  <ArrowRight size={15} />
                </button>
              )}
            </div>
          </section>
          <aside className="surface question-palette">
            <div className="section-title">
              <h2>Question navigator</h2>
              <ListChecks size={18} />
            </div>
            <p>
              {answered} of {p.questions.length} answered
            </p>
            <div className="progress-track">
              <i
                style={{ width: `${(answered / p.questions.length) * 100}%` }}
              />
            </div>
            <div className="number-grid">
              {p.questions.map((item, i) => (
                <button
                  key={item.id}
                  aria-label={`Question ${i + 1}${draft.answers[item.id] !== undefined ? ", answered" : ""}${draft.flagged.includes(item.id) ? ", marked for review" : ""}`}
                  aria-current={draft.current === i ? "step" : undefined}
                  className={`${draft.answers[item.id] !== undefined ? "answered" : ""} ${draft.flagged.includes(item.id) ? "marked" : ""} ${draft.current === i ? "current" : ""}`}
                  onClick={() => setIndex(i)}
                >
                  {i + 1}
                </button>
              ))}
            </div>
            <div className="palette-key">
              <span>
                <i className="answered" />
                Answered
              </span>
              <span>
                <i />
                Unanswered
              </span>
              <span>
                <i className="marked" />
                For review
              </span>
            </div>
            <button
              className="primary-button full-width"
              onClick={() => setConfirm("submit")}
            >
              <Flag size={15} />
              Submit test
            </button>
          </aside>
        </div>
      </main>
      {confirm === "submit" && (
        <Modal title="Submit your test?" onClose={() => setConfirm(null)}>
          <div className="dialog-symbol violet">
            <Flag size={26} />
          </div>
          <p className="dialog-copy">
            Your marks will be calculated immediately. You won't be able to
            change your answers after submitting.
          </p>
          <div className="submit-summary">
            <span>
              Answered<strong>{answered}</strong>
            </span>
            <span>
              Unanswered<strong>{p.questions.length - answered}</strong>
            </span>
            <span>
              Marked for review<strong>{draft.flagged.length}</strong>
            </span>
          </div>
          <div className="modal-actions">
            <button
              className="secondary-button"
              onClick={() => setConfirm(null)}
            >
              Keep working
            </button>
            <button className="primary-button" onClick={onSubmit}>
              Confirm submission
              <Check size={15} />
            </button>
          </div>
        </Modal>
      )}
      {confirm === "exit" && (
        <Modal
          title="Save and leave this test?"
          onClose={() => setConfirm(null)}
        >
          <p className="dialog-copy">
            Your answers and review flags are saved. The timer will continue
            running while you're away. Resume the test from your dashboard.
          </p>
          <div className="modal-actions">
            <button
              className="secondary-button"
              onClick={() => setConfirm(null)}
            >
              Stay in test
            </button>
            <button className="primary-button" onClick={onExit}>
              Save & exit
              <ArrowRight size={15} />
            </button>
          </div>
        </Modal>
      )}
    </div>
  );
}
export function Result({ attempt: a, user }: { attempt: Attempt; user: User }) {
  const [filter, setFilter] = useState("All questions"),
    [open, setOpen] = useState<string | null>(null);
  const state = (q: (typeof a.questions)[number]) =>
    a.answers[q.id] === undefined
      ? "Unanswered"
      : a.answers[q.id] === q.correct
        ? "Correct"
        : "Incorrect";
  const rows = a.questions
    .map((q, i) => ({ q, i }))
    .filter(({ q }) => filter === "All questions" || filter === state(q));
  return (
    <main className="page-container result-page">
      <Link
        className="back-link"
        to={user.role === "admin" ? "/admin/results" : "/analytics"}
      >
        <ArrowLeft size={14} />
        Back to {user.role === "admin" ? "student results" : "my analytics"}
      </Link>
      <div className="page-intro">
        <div>
          <div className="eyebrow">
            <i />
            TEST RESULT
          </div>
          <h1>{a.title}</h1>
          <p>
            {a.student} · {a.level} · Completed {shortDate(a.finishedAt)}
          </p>
        </div>
        <span className="completed-tag">
          <ShieldCheck size={15} />
          Submitted
        </span>
      </div>
      <section className="result-summary">
        <div
          className="score-ring"
          style={{
            background: `conic-gradient(#7852d8 ${Math.max(0, percent(a))}%, #e1d9f4 0)`,
          }}
        >
          <div>
            <strong>{percent(a)}%</strong>
            <span>Score</span>
          </div>
        </div>
        <div className="result-score">
          <span className="eyebrow">YOUR MARKS</span>
          <h2>
            {a.score}
            <small> / {a.total}</small>
          </h2>
          <p>
            <Clock3 size={14} />
            {Math.floor(a.elapsed / 60)} min {a.elapsed % 60} sec taken
          </p>
        </div>
        <div className="outcomes">
          <div>
            <span className="outcome-icon correct">
              <Check size={16} />
            </span>
            <strong>{a.correct}</strong>
            <small>Correct</small>
          </div>
          <div>
            <span className="outcome-icon incorrect">
              <X size={16} />
            </span>
            <strong>{a.incorrect}</strong>
            <small>Incorrect</small>
          </div>
          <div>
            <span className="outcome-icon unanswered">
              <span>−</span>
            </span>
            <strong>{a.unanswered}</strong>
            <small>Unanswered</small>
          </div>
        </div>
      </section>
      <div className="review-heading">
        <div>
          <h2>Answer review</h2>
          <p>Explore each response and its explanation.</p>
        </div>
        <select
          className="standalone-select"
          aria-label="Filter answer review"
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
        >
          {["All questions", "Correct", "Incorrect", "Unanswered"].map((v) => (
            <option key={v}>{v}</option>
          ))}
        </select>
      </div>
      <div className="review-list">
        {rows.map(({ q, i }) => {
          const status = state(q),
            expanded = open === q.id;
          return (
            <section className="surface review-item" key={q.id}>
              <button
                className="review-row"
                onClick={() => setOpen(expanded ? null : q.id)}
                aria-expanded={expanded}
              >
                <span className="review-number">
                  {String(i + 1).padStart(2, "0")}
                </span>
                <span className="review-question">
                  <MathText text={q.text} />
                </span>
                <span className={`status-label ${status.toLowerCase()}`}>
                  {status}
                </span>
                <span className="expand-sign">{expanded ? "−" : "+"}</span>
              </button>
              {expanded && (
                <div className="review-details">
                  {q.choices.map((c, j) => (
                    <div
                      key={j}
                      className={`review-option ${q.correct === j ? "correct" : a.answers[q.id] === j ? "incorrect" : ""}`}
                    >
                      <b>{String.fromCharCode(65 + j)}</b>
                      <MathText text={c} />
                      <small>
                        {q.correct === j
                          ? "Correct answer"
                          : a.answers[q.id] === j
                            ? "Your answer"
                            : ""}
                        {q.correct === j && a.answers[q.id] === j
                          ? " · Your answer"
                          : ""}
                      </small>
                    </div>
                  ))}
                  <div className="solution">
                    <GraduationCap size={19} />
                    <div>
                      <strong>Explanation</strong>
                      <p>
                        <MathText text={q.explanation} />
                      </p>
                    </div>
                  </div>
                </div>
              )}
            </section>
          );
        })}
        {!rows.length && (
          <p className="surface empty-filter">
            No {filter.toLowerCase()} responses in this attempt.
          </p>
        )}
      </div>
    </main>
  );
}
