import { useState } from "react";
import {
  ArrowRight,
  BookOpenCheck,
  CheckCheck,
  Download,
  Target,
  Timer,
  Trophy,
  TrendingUp,
  ChevronRight,
  Search,
} from "lucide-react";
import { Link } from "react-router-dom";
import { type Attempt, percent, shortDate, subjectClass } from "../lib/types";
import { EmptyState, PageIntro, SubjectIcon } from "../components/ui";
import { Performance } from "../components/Performance";
import { exportResults } from "../lib/results";
export function ResultsTable({
  attempts,
  admin = false,
}: {
  attempts: Attempt[];
  admin?: boolean;
}) {
  const [query, setQuery] = useState("");
  const data = [...attempts]
    .sort((a, b) => b.finishedAt - a.finishedAt)
    .filter((a) =>
      `${a.title} ${a.student} ${a.subject}`
        .toLowerCase()
        .includes(query.toLowerCase()),
    );
  return (
    <section className="surface results-table" id="history">
      <div className="table-title">
        <div>
          <h2>{admin ? "Student results" : "Test history"}</h2>
          <p>
            {admin
              ? "Completed attempts from your student workspace."
              : "Every attempt, with a complete answer review."}
          </p>
        </div>
        <div className="search-field compact-search">
          <Search size={15} />
          <input
            aria-label="Search results"
            placeholder="Search results…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
        </div>
      </div>
      {data.length ? (
        <div className="table-scroller">
          <table>
            <thead>
              <tr>
                <th>Test paper</th>
                {admin && <th>Student</th>}
                <th>Date</th>
                <th>Marks</th>
                <th>Score</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {data.map((a) => (
                <tr key={a.id}>
                  <td>
                    <div className="table-paper">
                      <span
                        className={`subject-tile ${subjectClass(a.subject)}`}
                      >
                        <SubjectIcon subject={a.subject} size={18} />
                      </span>
                      <span>
                        <strong>{a.title}</strong>
                        <small>
                          {a.level} · {a.subject}
                        </small>
                      </span>
                    </div>
                  </td>
                  {admin && <td>{a.student}</td>}
                  <td>{shortDate(a.finishedAt)}</td>
                  <td>
                    {a.score} <span className="muted">/ {a.total}</span>
                  </td>
                  <td>
                    <span
                      className={`score-badge ${percent(a) < 50 ? "low" : ""}`}
                    >
                      {percent(a)}%
                    </span>
                  </td>
                  <td>
                    <Link
                      className="table-link"
                      to={`/results/${a.id}`}
                      aria-label={`Review ${a.title} result`}
                    >
                      Review
                      <ChevronRight size={14} />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      ) : (
        <EmptyState
          title={query ? "No matching results" : "No completed tests yet"}
          detail={
            query
              ? "Try a different test or student name."
              : "Your completed test attempts will appear here."
          }
        />
      )}
    </section>
  );
}
export function Analytics({ attempts }: { attempts: Attempt[] }) {
  const count = attempts.length,
    answered = attempts.reduce((s, a) => s + a.correct + a.incorrect, 0),
    correct = attempts.reduce((s, a) => s + a.correct, 0),
    minutes = Math.round(attempts.reduce((s, a) => s + a.elapsed, 0) / 60),
    best = count ? Math.max(...attempts.map(percent)) : 0;
  const bySubject: Record<string, { earned: number; total: number }> = {};
  attempts.forEach((a) =>
    a.questions.forEach((q) => {
      const s = bySubject[q.subject] ?? { earned: 0, total: 0 };
      s.total += q.marks;
      s.earned +=
        a.answers[q.id] === undefined
          ? 0
          : a.answers[q.id] === q.correct
            ? q.marks
            : -a.negative;
      bySubject[q.subject] = s;
    }),
  );
  return (
    <main className="page-container">
      <PageIntro
        eyebrow="LEARNING INSIGHTS"
        title="My analytics"
        description="A closer look at your marks, progress, and subject strengths."
        aside={
          <button
            className="secondary-button"
            onClick={() => exportResults(attempts)}
            disabled={!count}
          >
            <Download size={15} />
            Export results
          </button>
        }
      />
      <div className="metric-grid">
        {[
          {
            icon: BookOpenCheck,
            title: "Tests completed",
            value: String(count).padStart(2, "0"),
            color: "violet",
          },
          {
            icon: Target,
            title: "Answer accuracy",
            value: `${answered ? Math.round((correct / answered) * 100) : 0}%`,
            color: "mint",
          },
          {
            icon: Trophy,
            title: "Personal best",
            value: `${best}%`,
            color: "apricot",
          },
          {
            icon: Timer,
            title: "Practice time",
            value: `${Math.floor(minutes / 60)}h ${minutes % 60}m`,
            color: "sky",
          },
        ].map(({ icon: Icon, title, value, color }) => (
          <div className="surface metric" key={title}>
            <span className={`icon-tile ${color}`}>
              <Icon size={20} />
            </span>
            <div>
              <p>{title}</p>
              <strong>{value}</strong>
            </div>
          </div>
        ))}
      </div>
      <div className="analytics-grid">
        <Performance attempts={attempts} expanded />
        <section className="surface subject-breakdown">
          <div className="section-title">
            <h2>Subject breakdown</h2>
            <span className="small-violet-icon">
              <TrendingUp size={17} />
            </span>
          </div>
          <p>Marks earned across all your attempts.</p>
          {Object.keys(bySubject).length ? (
            Object.entries(bySubject)
              .sort(
                (a, b) => b[1].earned / b[1].total - a[1].earned / a[1].total,
              )
              .map(([s, d]) => (
                <div className={`subject-progress ${s.toLowerCase()}`} key={s}>
                  <div>
                    <span>{s}</span>
                    <strong>{Math.round((d.earned / d.total) * 100)}%</strong>
                  </div>
                  <div className="progress-track">
                    <i
                      style={{
                        width: `${Math.max(0, (d.earned / d.total) * 100)}%`,
                      }}
                    />
                  </div>
                  <small>
                    {d.earned} of {d.total} marks
                  </small>
                </div>
              ))
          ) : (
            <EmptyState
              title="Your strengths start here"
              detail="Take a test to see subject-wise marks."
            />
          )}
          <div className="insight-note">
            <CheckCheck size={17} />
            <span>
              Every completed test updates your insights automatically.
            </span>
          </div>
        </section>
      </div>
      <ResultsTable attempts={attempts} />
      {!count && (
        <Link className="primary-button inline-action" to="/library">
          Find your first test
          <ArrowRight size={16} />
        </Link>
      )}
    </main>
  );
}
