import { useState } from "react";
import {
  ArrowRight,
  Award,
  CalendarDays,
  Clock3,
  Files,
  Sparkles,
  Timer,
  Compass,
  BookOpen,
} from "lucide-react";
import { Link } from "react-router-dom";
import {
  type Attempt,
  type Draft,
  type Paper,
  type User,
  totalMarks,
} from "../lib/types";
import { Performance, RecentResults } from "../components/Performance";
import { LevelTabs, TestCard } from "../components/TestCard";
import { EmptyState, TextLink } from "../components/ui";
export function Dashboard({
  user,
  papers,
  attempts,
  onStart,
  draft,
}: {
  user: User;
  papers: Paper[];
  attempts: Attempt[];
  onStart: (p: Paper) => void;
  draft: Draft | null;
}) {
  const [level, setLevel] = useState("All levels"),
    available = papers.filter((p) => p.published),
    featured = available.find((p) => p.id === "jee-mock-01") ?? available[0],
    filtered = available.filter((p) =>
      level === "All levels" ? p.id !== featured?.id : p.level === level,
    );
  const first = user.name.split(" ")[0];
  return (
    <main className="page-container dashboard">
      <div className="page-intro dashboard-intro">
        <div>
          <div className="eyebrow">
            <i />
            STUDENT WORKSPACE
          </div>
          <h1>
            Welcome back, {first}
            <span className="greeting-wave">👋</span>
          </h1>
          <p>
            A new day, a fresh opportunity to put your knowledge to the test.
          </p>
        </div>
        <span className="date-chip">
          <CalendarDays size={15} />
          {new Date().toLocaleDateString("en-GB", {
            weekday: "long",
            day: "numeric",
            month: "long",
          })}
        </span>
      </div>
      {draft && (
        <div className="resume-strip">
          <Timer size={17} />
          <span>
            Your test <strong>{draft.paper.title}</strong> is in progress.
          </span>
          <Link to="/exam">
            Resume test
            <ArrowRight size={14} />
          </Link>
        </div>
      )}
      {featured && (
        <section className="featured-banner">
          <div className="banner-grid" />
          <div className="banner-orbit orbit-one" />
          <div className="banner-orbit orbit-two" />
          <div className="banner-copy">
            <span className="feature-tag">
              <Sparkles size={12} />
              FEATURED{" "}
              {featured.type === "Mock test" ? "MOCK TEST" : "PRACTICE"}
            </span>
            <h2>{featured.title}</h2>
            <p>
              {featured.id === "jee-mock-01"
                ? "Your exam-day rehearsal for Physics, Chemistry & Mathematics."
                : featured.description}
            </p>
            <div className="featured-meta">
              <span>
                <Files size={15} />
                {featured.questions.length} questions
              </span>
              <i />
              <span>
                <Clock3 size={15} />
                {featured.minutes} min
              </span>
              <i />
              <span>
                <Award size={16} />
                {totalMarks(featured)} marks
              </span>
            </div>
            <button
              className="primary-button banner-cta"
              onClick={() => onStart(featured)}
            >
              {draft?.paper.id === featured.id
                ? "Resume test"
                : featured.type === "Mock test"
                  ? "Start mock test"
                  : "Start practice test"}
              <ArrowRight size={16} />
            </button>
          </div>
          <div className="banner-illustration" aria-hidden="true">
            <span className="math-doodle d1">x² + y²</span>
            <span className="math-doodle d2">∑</span>
            <span className="math-doodle d3">+</span>
            <span className="math-doodle d4">✦</span>
            <svg className="doodle-orbit" viewBox="0 0 340 170" fill="none">
              <path
                d="M15 106C-8 56 303 4 318 57s-239 99-269 87"
                stroke="currentColor"
                strokeDasharray="4 5"
                strokeWidth="1.3"
              />
            </svg>
            <img
              src="/images/learning-still-life.webp"
              alt=""
              fetchPriority="high"
            />
          </div>
        </section>
      )}
      <div className="dashboard-columns">
        <section className="available-section">
          <div className="section-title library-title">
            <div>
              <div className="section-kicker">
                <span className="kicker-line" />
                EXPLORE & PRACTICE
              </div>
              <h2>Test library</h2>
            </div>
            <TextLink to="/library">View all tests</TextLink>
          </div>
          <LevelTabs value={level} onChange={setLevel} />
          <div className="dashboard-test-grid">
            {filtered.slice(0, 4).map((p) => (
              <TestCard
                key={p.id}
                paper={p}
                onStart={onStart}
                resume={draft?.paper.id === p.id}
              />
            ))}
          </div>
          {!filtered.length && (
            <EmptyState
              title="No tests at this level yet"
              detail="Choose another level or explore the full test library."
            />
          )}
          {filtered.length > 4 && (
            <Link className="browse-more" to="/library">
              <BookOpen size={16} />
              Explore the complete library
              <ArrowRight size={15} />
            </Link>
          )}
        </section>
        <aside className="dashboard-sidebar">
          <Performance attempts={attempts} />
          <RecentResults attempts={attempts} />
          <div className="study-note">
            <span>
              <Compass size={19} />
            </span>
            <div>
              <strong>A little study tip</strong>
              <p>
                Review your incorrect answers before starting your next test.
              </p>
            </div>
          </div>
        </aside>
      </div>
    </main>
  );
}
