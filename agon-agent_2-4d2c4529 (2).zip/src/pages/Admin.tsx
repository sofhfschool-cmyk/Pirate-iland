import { useState } from "react";
import { Link, useLocation } from "react-router-dom";
import {
  ArrowRight,
  BookOpen,
  CheckCheck,
  Download,
  Eye,
  EyeOff,
  FileCode2,
  Files,
  Pencil,
  Plus,
  Search,
  Trash2,
  Upload,
  Users,
} from "lucide-react";
import {
  type Paper,
  type Attempt,
  type User,
  levels,
  subjectClass,
} from "../lib/types";
import {
  EmptyState,
  Modal,
  PageIntro,
  SubjectIcon,
  TextLink,
} from "../components/ui";
import { downloadFile, sampleLatex } from "../lib/latex";
import { ResultsTable } from "./Analytics";
import { exportResults } from "../lib/results";
import { PaperEditor } from "./PaperEditor";
export function Admin({
  papers,
  attempts,
  user,
  onSave,
  onDelete,
  notify,
}: {
  papers: Paper[];
  attempts: Attempt[];
  user: User;
  onSave: (p: Paper) => Promise<boolean>;
  onDelete: (id: string) => Promise<boolean>;
  notify: (s: string) => void;
}) {
  const loc = useLocation(),
    section = loc.pathname.endsWith("/results")
      ? "results"
      : loc.pathname.endsWith("/papers")
        ? "papers"
        : "overview",
    [editor, setEditor] = useState<Paper | "new" | null>(null),
    [deleting, setDeleting] = useState<Paper | null>(null),
    [query, setQuery] = useState(""),
    [level, setLevel] = useState("All levels");
  const filtered = papers.filter(
      (p) =>
        p.title.toLowerCase().includes(query.toLowerCase()) &&
        (level === "All levels" || p.level === level),
    ),
    visible = section === "overview" ? filtered.slice(0, 5) : filtered;
  return (
    <main className="page-container admin-page">
      <PageIntro
        eyebrow="ADMIN WORKSPACE"
        title={
          section === "results"
            ? "Student results"
            : section === "papers"
              ? "Question papers"
              : `Welcome back, ${user.name.split(" ")[0]}`
        }
        description={
          section === "results"
            ? "Review student marks and dive into individual attempts."
            : section === "papers"
              ? "Create, edit, and publish papers for your students."
              : "Your question papers, students, and assessment overview."
        }
        aside={
          section === "results" ? (
            <button
              className="secondary-button"
              disabled={!attempts.length}
              onClick={() => exportResults(attempts)}
            >
              <Download size={16} />
              Export results
            </button>
          ) : (
            <button className="primary-button" onClick={() => setEditor("new")}>
              <Plus size={16} />
              Create paper
            </button>
          )
        }
      />
      {section === "overview" && (
        <>
          <div className="metric-grid admin-metrics">
            {[
              {
                icon: Files,
                title: "Total papers",
                value: papers.length,
                color: "violet",
              },
              {
                icon: BookOpen,
                title: "Published tests",
                value: papers.filter((p) => p.published).length,
                color: "mint",
              },
              {
                icon: Users,
                title: "Active students",
                value: new Set(attempts.map((a) => a.userId)).size,
                color: "sky",
              },
              {
                icon: CheckCheck,
                title: "Completed attempts",
                value: attempts.length,
                color: "apricot",
              },
            ].map(({ icon: Icon, title, value, color }) => (
              <div className="surface metric" key={title}>
                <span className={`icon-tile ${color}`}>
                  <Icon size={21} />
                </span>
                <div>
                  <p>{title}</p>
                  <strong>{String(value).padStart(2, "0")}</strong>
                </div>
              </div>
            ))}
          </div>
          <section className="latex-studio">
            <div className="studio-icon">
              <FileCode2 size={40} />
            </div>
            <div>
              <span className="section-kicker">PAPER AUTHORING</span>
              <h2>Your LaTeX paper studio</h2>
              <p>
                Upload a .tex file, preview the mathematics, and publish a
                ready-to-take test.
              </p>
            </div>
            <button className="primary-button" onClick={() => setEditor("new")}>
              <Upload size={15} />
              Upload LaTeX
            </button>
          </section>
        </>
      )}
      {section === "results" ? (
        <ResultsTable attempts={attempts} admin />
      ) : (
        <section className="surface admin-paper-table">
          <div className="table-title">
            <div>
              <h2>
                {section === "overview"
                  ? "Question papers"
                  : "Paper collection"}
              </h2>
              <p>{papers.length} papers across Classes VIII–XII and JEE Main</p>
            </div>
            {section === "overview" ? (
              <TextLink to="/admin/papers">View all</TextLink>
            ) : (
              <button
                className="text-link"
                onClick={() =>
                  downloadFile("pi-rate-question-template.tex", sampleLatex)
                }
              >
                <Download size={14} />
                LaTeX template
              </button>
            )}
          </div>
          <div className="table-filters">
            <div className="search-field">
              <Search size={15} />
              <input
                aria-label="Search question papers"
                placeholder="Search question papers…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <select
              className="standalone-select"
              aria-label="Filter paper level"
              value={level}
              onChange={(e) => setLevel(e.target.value)}
            >
              {["All levels", ...levels].map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
          </div>
          {visible.length ? (
            <div className="table-scroller">
              <table>
                <thead>
                  <tr>
                    <th>Question paper</th>
                    <th>Level</th>
                    <th>Questions</th>
                    <th>Duration</th>
                    <th>Status</th>
                    <th>Manage</th>
                  </tr>
                </thead>
                <tbody>
                  {visible.map((p) => (
                    <tr key={p.id}>
                      <td>
                        <div className="table-paper">
                          <span
                            className={`subject-tile ${subjectClass(p.subject)}`}
                          >
                            <SubjectIcon subject={p.subject} size={19} />
                          </span>
                          <span>
                            <strong>{p.title}</strong>
                            <small>
                              {p.subject} · {p.type}
                            </small>
                          </span>
                        </div>
                      </td>
                      <td>{p.level}</td>
                      <td>{p.questions.length}</td>
                      <td>{p.minutes} min</td>
                      <td>
                        <span
                          className={`publication-badge ${p.published ? "live" : ""}`}
                        >
                          <i />
                          {p.published ? "Published" : "Draft"}
                        </span>
                      </td>
                      <td>
                        <div className="table-controls">
                          <button
                            className="icon-button"
                            title="Edit paper"
                            aria-label={`Edit ${p.title}`}
                            onClick={() => setEditor(p)}
                          >
                            <Pencil size={15} />
                          </button>
                          <button
                            className="icon-button"
                            title={
                              p.published ? "Unpublish paper" : "Publish paper"
                            }
                            aria-label={`${p.published ? "Unpublish" : "Publish"} ${p.title}`}
                            onClick={async () => {
                              if (!(await onSave({ ...p, published: !p.published }))) return;
                              notify(
                                p.published
                                  ? "Paper moved to drafts."
                                  : "Paper published to the test library.",
                              );
                            }}
                          >
                            {p.published ? (
                              <Eye size={16} />
                            ) : (
                              <EyeOff size={16} />
                            )}
                          </button>
                          {p.id.startsWith("paper-") && (
                            <button
                              className="icon-button danger"
                              title="Delete paper"
                              aria-label={`Delete ${p.title}`}
                              onClick={() => setDeleting(p)}
                            >
                              <Trash2 size={15} />
                            </button>
                          )}
                        </div>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <EmptyState
              title="No matching papers"
              detail="Try another title or level."
            />
          )}
        </section>
      )}
      {section === "overview" && (
        <div className="admin-results-link">
          <span>
            <CheckCheck size={19} />
            Explore student marks and completed attempts.
          </span>
          <Link className="text-link" to="/admin/results">
            Student results
            <ArrowRight size={15} />
          </Link>
        </div>
      )}
      {editor && (
        <PaperEditor
          paper={editor === "new" ? null : editor}
          onClose={() => setEditor(null)}
          onSave={async (p) => {
            if (!(await onSave(p))) return;
            setEditor(null);
            notify(
              p.published
                ? "Paper saved and published to the test library."
                : "Draft saved successfully.",
            );
          }}
        />
      )}
      {deleting && (
        <Modal
          title="Delete this question paper?"
          onClose={() => setDeleting(null)}
        >
          <p className="dialog-copy">
            <strong>{deleting.title}</strong> will be removed from your library.
            Completed student results will be preserved. This action cannot be
            undone.
          </p>
          <div className="modal-actions">
            <button
              className="secondary-button"
              onClick={() => setDeleting(null)}
            >
              Cancel
            </button>
            <button
              className="danger-button"
              onClick={async () => {
                if (!(await onDelete(deleting.id))) return;
                setDeleting(null);
                notify("Question paper deleted.");
              }}
            >
              Delete paper
            </button>
          </div>
        </Modal>
      )}
    </main>
  );
}
