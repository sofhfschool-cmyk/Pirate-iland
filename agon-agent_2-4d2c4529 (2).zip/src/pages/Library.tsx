import { useMemo, useState } from "react";
import { Search, SlidersHorizontal, X, BookOpen } from "lucide-react";
import { LevelTabs, TestCard } from "../components/TestCard";
import { EmptyState, PageIntro } from "../components/ui";
import { subjects, type Paper, type Draft } from "../lib/types";
export function Library({
  papers,
  onStart,
  draft,
}: {
  papers: Paper[];
  onStart: (p: Paper) => void;
  draft: Draft | null;
}) {
  const [level, setLevel] = useState("All levels"),
    [query, setQuery] = useState(""),
    [subject, setSubject] = useState("All subjects"),
    [order, setOrder] = useState("recommended");
  const all = papers.filter((p) => p.published);
  const filtered = useMemo(() => {
    const list = all.filter(
      (p) =>
        (level === "All levels" || p.level === level) &&
        (subject === "All subjects" || subject === p.subject) &&
        `${p.title} ${p.subject} ${p.level}`
          .toLowerCase()
          .includes(query.toLowerCase()),
    );
    if (order === "short") list.sort((a, b) => a.minutes - b.minutes);
    if (order === "title") list.sort((a, b) => a.title.localeCompare(b.title));
    return list;
  }, [all, level, subject, query, order]);
  const reset = () => {
    setQuery("");
    setSubject("All subjects");
    setLevel("All levels");
    setOrder("recommended");
  };
  return (
    <main className="page-container">
      <PageIntro
        eyebrow="EXPLORE & PRACTICE"
        title="Test library"
        description="Find the right practice paper for your next learning milestone."
        aside={
          <span className="date-chip">
            <BookOpen size={16} />
            {all.length} available tests
          </span>
        }
      />
      <div className="library-tools surface">
        <div className="search-field">
          <Search size={17} />
          <input
            aria-label="Search tests"
            placeholder="Search by test, subject, or class…"
            value={query}
            onChange={(e) => setQuery(e.target.value)}
          />
          {query && (
            <button aria-label="Clear search" onClick={() => setQuery("")}>
              <X size={15} />
            </button>
          )}
        </div>
        <label className="select-field">
          <SlidersHorizontal size={15} />
          <select
            aria-label="Filter by subject"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          >
            <option>All subjects</option>
            {subjects.map((s) => (
              <option key={s}>{s}</option>
            ))}
          </select>
        </label>
        <label className="select-field">
          <select
            aria-label="Sort tests"
            value={order}
            onChange={(e) => setOrder(e.target.value)}
          >
            <option value="recommended">Recommended</option>
            <option value="short">Shortest first</option>
            <option value="title">Title: A–Z</option>
          </select>
        </label>
      </div>
      <div className="library-filter-row">
        <LevelTabs value={level} onChange={setLevel} />
        <span>
          {filtered.length} {filtered.length === 1 ? "test" : "tests"}
        </span>
      </div>
      {filtered.length ? (
        <div className="library-grid">
          {filtered.map((p) => (
            <TestCard
              key={p.id}
              paper={p}
              onStart={onStart}
              resume={draft?.paper.id === p.id}
            />
          ))}
        </div>
      ) : (
        <div className="surface">
          <EmptyState
            title="No matching tests"
            detail="Try another keyword, class, or subject."
            action={
              <button className="secondary-button" onClick={reset}>
                Clear filters
              </button>
            }
          />
        </div>
      )}
    </main>
  );
}
