import { useState, type FormEvent } from "react";
import { Link, useSearchParams } from "react-router-dom";
import {
  ArrowLeft,
  ArrowRight,
  Eye,
  EyeOff,
  GraduationCap,
  ShieldCheck,
  Sparkles,
  Check,
  LockKeyhole,
  Info,
} from "lucide-react";
import { Brand } from "../components/ui";
import { type User, type Role, type Level, levels } from "../lib/types";
import { isSharedDatabase, login, loginDemo, signup } from "../lib/storage";
import { adminDemo, studentDemo } from "../lib/data";
export function Auth({
  onLogin,
  current,
}: {
  onLogin: (u: User) => void;
  current: User | null;
}) {
  const [params] = useSearchParams(),
    [role, setRole] = useState<Role>(
      params.get("role") === "admin" ? "admin" : "student",
    ),
    [register, setRegister] = useState(false),
    [email, setEmail] = useState(""),
    [password, setPassword] = useState(""),
    [name, setName] = useState(""),
    [level, setLevel] = useState<Level>("Class XII"),
    [show, setShow] = useState(false),
    [busy, setBusy] = useState(false),
    [error, setError] = useState(""),
    [details, setDetails] = useState(false);
  function changeRole(r: Role) {
    setRole(r);
    setRegister(false);
    setError("");
    setEmail("");
    setPassword("");
    setDetails(false);
  }
  async function submit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      if (register && name.trim().length < 2)
        throw new Error("Please enter your full name.");
      onLogin(
        register
          ? await signup(name, email, password, level)
          : await login(email, password, role),
      );
    } catch (e) {
      setError(
        e instanceof Error ? e.message : "Unable to sign in. Please try again.",
      );
    } finally {
      setBusy(false);
    }
  }
  const admin = role === "admin",
    demo = admin ? adminDemo : studentDemo;
  return (
    <main className="auth-page">
      <div className="auth-top">
        <Brand />
        {current && (
          <Link to={current.role === "admin" ? "/admin" : "/"}>
            <ArrowLeft size={15} />
            Back to workspace
          </Link>
        )}
      </div>
      <div className="auth-shell">
        <aside className="auth-story">
          <span className="feature-tag">
            <Sparkles size={12} />
            THE LEARNING WORKSPACE
          </span>
          <h1>
            Small steps.
            <br />
            Stronger scores.
          </h1>
          <p>Your practice, progress, and potential. All in one place.</p>
          <img
            src="/images/learning-still-life.webp"
            alt="A graduation cap, colorful books, and geometry tools"
          />
          <div className="auth-features">
            <span>
              <Check size={14} />
              Classes VIII–XII
            </span>
            <span>
              <Check size={14} />
              JEE Main
            </span>
            <span>
              <Check size={14} />
              LaTeX ready
            </span>
          </div>
        </aside>
        <section className="auth-form-panel">
          <div className="role-switch">
            <button
              className={!admin ? "selected" : ""}
              onClick={() => changeRole("student")}
            >
              <GraduationCap size={16} />
              Student
            </button>
            <button
              className={admin ? "selected" : ""}
              onClick={() => changeRole("admin")}
            >
              <ShieldCheck size={16} />
              Admin
            </button>
          </div>
          <div className="eyebrow">
            <i />
            {admin ? "ADMIN WORKSPACE" : "STUDENT WORKSPACE"}
          </div>
          <h2>
            {register
              ? "Create your account"
              : admin
                ? "Admin sign in"
                : "Welcome back"}
          </h2>
          <p>
            {register
              ? "Start your personal practice journey."
              : admin
                ? "Manage question papers and student results."
                : "Sign in to continue your learning journey."}
          </p>
          <form onSubmit={submit}>
            {register && (
              <div className="form-row">
                <label>
                  Full name
                  <input
                    required
                    maxLength={60}
                    autoComplete="name"
                    placeholder="Your full name"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                  />
                </label>
                <label>
                  Learning level
                  <select
                    aria-label="Learning level"
                    value={level}
                    onChange={(e) => setLevel(e.target.value as Level)}
                  >
                    {levels.map((l) => (
                      <option key={l}>{l}</option>
                    ))}
                  </select>
                </label>
              </div>
            )}
            <label>
              Email address
              <input
                type="email"
                autoComplete="email"
                required
                placeholder={admin ? "admin@school.edu" : "you@example.com"}
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
            </label>
            <label>
              Password
              <div className="password-input">
                <input
                  aria-label="Password"
                  type={show ? "text" : "password"}
                  autoComplete={register ? "new-password" : "current-password"}
                  required
                  minLength={register ? 8 : 1}
                  placeholder={
                    register ? "At least 8 characters" : "Enter your password"
                  }
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                />
                <button
                  type="button"
                  onClick={() => setShow(!show)}
                  aria-label={show ? "Hide password" : "Show password"}
                >
                  {show ? <EyeOff size={16} /> : <Eye size={16} />}
                </button>
              </div>
            </label>
            {error && (
              <div className="form-error" role="alert">
                {error}
              </div>
            )}
            <button className="primary-button full-width" disabled={busy}>
              {busy
                ? "Please wait…"
                : register
                  ? "Create student account"
                  : "Sign in"}
              <ArrowRight size={16} />
            </button>
          </form>
          {!admin && (
            <p className="auth-toggle">
              {register ? "Already have an account?" : "New to π-rate i-Land?"}{" "}
              <button
                onClick={() => {
                  setRegister(!register);
                  setError("");
                }}
              >
                {register ? "Sign in" : "Create an account"}
              </button>
            </p>
          )}
          <div className="or-line">
            <span />
            or explore the demo
            <span />
          </div>
          <button
            className="secondary-button full-width"
            disabled={busy}
            onClick={async () => { setBusy(true); setError(""); try { onLogin(await loginDemo(demo)); } catch (e) { setError(e instanceof Error ? e.message : "Unable to open the workspace."); } finally { setBusy(false); } }}
          >
            {admin ? <ShieldCheck size={16} /> : <GraduationCap size={17} />}Try{" "}
            {admin ? "admin" : "student"} demo
            <ArrowRight size={15} />
          </button>
          <button
            className="demo-credentials"
            onClick={() => setDetails(!details)}
          >
            <Info size={13} />
            {details ? "Hide" : "View"} demo credentials
          </button>
          {details && (
            <div className="credentials-box">
              <span>
                Email: <strong>{demo.email}</strong>
              </span>
              <span>
                Password: <strong>{admin ? "Admin@123" : "Student@123"}</strong>
                <button
                  onClick={() => {
                    setEmail(demo.email);
                    setPassword(admin ? "Admin@123" : "Student@123");
                    setRegister(false);
                  }}
                >
                  Fill in
                </button>
              </span>
            </div>
          )}
          <div className="local-note">
            <LockKeyhole size={12} />
            {isSharedDatabase() ? "Workspace data is saved in the platform’s shared database." : "This demo workspace saves accounts and data in this browser’s database."}
          </div>
        </section>
      </div>
      <div className="auth-copyright">π-rate i-Land · Learn with purpose.</div>
    </main>
  );
}
