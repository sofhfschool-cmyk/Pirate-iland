import { useMemo, useRef, useState, type FormEvent } from "react";
import {
  Upload,
  Download,
  FileCode2,
  Code2,
  Eye,
  CheckCircle2,
  CircleAlert,
  Save,
  ArrowRight,
  ChevronDown,
} from "lucide-react";
import {
  type Paper,
  type Subject,
  type Level,
  subjects,
  levels,
} from "../lib/types";
import { downloadFile, parseLatex, sampleLatex, toLatex } from "../lib/latex";
import { MathText, Modal } from "../components/ui";
export function PaperEditor({
  paper,
  onClose,
  onSave,
}: {
  paper: Paper | null;
  onClose: () => void;
  onSave: (p: Paper) => void;
}) {
  const [title, setTitle] = useState(paper?.title ?? ""),
    [level, setLevel] = useState<Level>(paper?.level ?? "Class XII"),
    [subject, setSubject] = useState<Subject>(paper?.subject ?? "Mathematics"),
    [minutes, setMinutes] = useState(paper?.minutes ?? 30),
    [negative, setNegative] = useState(paper?.negative ?? 0),
    [source, setSource] = useState(
      paper?.source ?? (paper ? toLatex(paper.questions) : sampleLatex),
    ),
    [tab, setTab] = useState<"code" | "preview">("code"),
    [error, setError] = useState(""),
    [file, setFile] = useState(""),
    [drag, setDrag] = useState(false),
    [help, setHelp] = useState(false),
    [published, setPublished] = useState(paper?.published ?? true),
    [kind, setKind] = useState<Paper["type"]>(paper?.type ?? "Practice test");
  const input = useRef<HTMLInputElement>(null),
    parsed = useMemo(() => parseLatex(source, subject), [source, subject]);
  async function importFile(f: File | undefined) {
    if (!f) return;
    setError("");
    if (!f.name.toLowerCase().endsWith(".tex")) {
      setError("Please select a .tex LaTeX source file.");
      return;
    }
    if (f.size > 1024 * 1024) {
      setError("The LaTeX file must be smaller than 1 MB.");
      return;
    }
    try {
      const text = await f.text();
      setSource(text);
      setFile(f.name);
      if (!title) setTitle(f.name.replace(/\.tex$/i, "").replace(/[_-]/g, " "));
      setTab("code");
    } catch {
      setError("This file could not be read. Try selecting it again.");
    }
  }
  function save(e: FormEvent) {
    e.preventDefault();
    if (!title.trim()) {
      setError("Enter a title for this question paper.");
      return;
    }
    if (parsed.error) {
      setError(parsed.error);
      return;
    }
    if (
      !Number.isFinite(minutes) ||
      minutes < 1 ||
      minutes > 360 ||
      negative < 0 ||
      negative > 10
    ) {
      setError(
        "Use a time limit of 1–360 minutes and a penalty of 0–10 marks.",
      );
      return;
    }
    const questions = parsed.questions.map((q, i) => ({
      ...q,
      subject:
        subject === "Mixed subjects"
          ? (paper?.questions[i]?.subject ?? subject)
          : subject,
    }));
    onSave({
      id: paper?.id ?? `paper-${crypto.randomUUID()}`,
      title: title.trim(),
      description: `${kind} in ${subject} for ${level}.`,
      level,
      subject,
      minutes,
      negative,
      questions,
      published,
      type: kind,
      source,
    });
  }
  return (
    <Modal
      title={paper ? "Edit question paper" : "Create a question paper"}
      onClose={onClose}
      wide
    >
      <p className="modal-subtitle">
        Set up your test and import questions with LaTeX.
      </p>
      <form className="paper-form" onSubmit={save}>
        <label>
          Paper title
          <input
            required
            maxLength={90}
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Calculus — Chapter Practice 01"
          />
        </label>
        <div className="editor-fields">
          <label>
            Level
            <select
              aria-label="Level"
              value={level}
              onChange={(e) => setLevel(e.target.value as Level)}
            >
              {levels.map((l) => (
                <option key={l}>{l}</option>
              ))}
            </select>
          </label>
          <label>
            Subject
            <select
              aria-label="Subject"
              value={subject}
              onChange={(e) => setSubject(e.target.value as Subject)}
            >
              {subjects.map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <label>
            Test type
            <select
              aria-label="Test type"
              value={kind}
              onChange={(e) => setKind(e.target.value as Paper["type"])}
            >
              {["Practice test", "Chapter test", "Mock test"].map((s) => (
                <option key={s}>{s}</option>
              ))}
            </select>
          </label>
          <label>
            Duration (min)
            <input
              type="number"
              min="1"
              max="360"
              required
              value={minutes}
              onChange={(e) => setMinutes(Number(e.target.value))}
            />
          </label>
          <label>
            Wrong answer penalty
            <input
              type="number"
              min="0"
              max="10"
              step="0.25"
              required
              value={negative}
              onChange={(e) => setNegative(Number(e.target.value))}
            />
          </label>
        </div>
        <input
          type="file"
          ref={input}
          accept=".tex,text/x-tex"
          hidden
          aria-label="Upload LaTeX question paper"
          onChange={(e) => {
            void importFile(e.target.files?.[0]);
            e.target.value = "";
          }}
        />
        <button
          type="button"
          className={`upload-zone ${drag ? "dragging" : ""}`}
          onClick={() => input.current?.click()}
          onDragOver={(e) => {
            e.preventDefault();
            setDrag(true);
          }}
          onDragLeave={() => setDrag(false)}
          onDrop={(e) => {
            e.preventDefault();
            setDrag(false);
            void importFile(e.dataTransfer.files[0]);
          }}
        >
          <span className="icon-tile violet">
            <Upload size={21} />
          </span>
          <span>
            <strong>{file || "Upload a LaTeX question paper"}</strong>
            <small>Choose a .tex file or drag it here · Up to 1 MB</small>
          </span>
          <ArrowRight size={17} />
        </button>
        <div className="editor-top">
          <div className="editor-tabs">
            <button
              type="button"
              className={tab === "code" ? "active" : ""}
              onClick={() => setTab("code")}
            >
              <Code2 size={15} />
              LaTeX source
            </button>
            <button
              type="button"
              className={tab === "preview" ? "active" : ""}
              onClick={() => setTab("preview")}
            >
              <Eye size={15} />
              Preview
            </button>
          </div>
          <button
            type="button"
            className="text-link"
            onClick={() =>
              downloadFile("pi-rate-question-template.tex", sampleLatex)
            }
          >
            <Download size={13} />
            Template
          </button>
        </div>
        {tab === "code" ? (
          <textarea
            className="latex-editor"
            aria-label="LaTeX source code"
            spellCheck={false}
            value={source}
            onChange={(e) => {
              setSource(e.target.value);
              setError("");
            }}
          />
        ) : (
          <div className="paper-preview">
            {parsed.questions.map((q, i) => (
              <div className="preview-question" key={q.id}>
                <strong>
                  Q{i + 1}. <MathText text={q.text} />
                </strong>
                <div>
                  {q.choices.map((c, j) => (
                    <p className={j === q.correct ? "correct" : ""} key={j}>
                      <b>{String.fromCharCode(65 + j)}.</b>
                      <MathText text={c} />
                      {j === q.correct && <CheckCircle2 size={14} />}
                    </p>
                  ))}
                </div>
              </div>
            ))}
            {!parsed.questions.length && (
              <p className="quiet-copy">
                A preview will appear when the source contains a valid question.
              </p>
            )}
          </div>
        )}
        <div className={`parse-state ${parsed.error ? "invalid" : ""}`}>
          {parsed.error ? (
            <>
              <CircleAlert size={15} />
              {parsed.error}
            </>
          ) : (
            <>
              <CheckCircle2 size={15} />
              {parsed.questions.length} questions parsed ·{" "}
              {parsed.questions.reduce((s, q) => s + q.marks, 0)} total marks
            </>
          )}
        </div>
        <button
          type="button"
          className="format-help"
          onClick={() => setHelp(!help)}
        >
          <FileCode2 size={14} />
          Supported LaTeX format
          <ChevronDown size={13} />
        </button>
        {help && (
          <div className="format-details">
            Use the exam-class <code>\question[marks]</code> format, with{" "}
            <code>\begin{"{choices}"}</code> and <code>\end{"{choices}"}</code>.
            Add 2–8 options with <code>\choice</code> and exactly one{" "}
            <code>\CorrectChoice</code>. Write inline math in <code>$…$</code>{" "}
            or display math in <code>$$…$$</code>. Optional{" "}
            <code>solution</code> blocks appear in the answer review. Documents
            with arbitrary LaTeX macros or external images are not supported.
          </div>
        )}
        <label className="publish-check">
          <input
            type="checkbox"
            checked={published}
            onChange={(e) => setPublished(e.target.checked)}
          />
          <span>
            <strong>Publish to the test library</strong>
            <small>
              {published
                ? "Students can start this paper as soon as you save it."
                : "Save as a draft, hidden from students."}
            </small>
          </span>
        </label>
        {error && (
          <div className="form-error" role="alert">
            {error}
          </div>
        )}
        <div className="modal-actions">
          <button type="button" className="secondary-button" onClick={onClose}>
            Cancel
          </button>
          <button className="primary-button">
            <Save size={15} />
            {paper
              ? "Save changes"
              : published
                ? "Publish paper"
                : "Save draft"}
          </button>
        </div>
      </form>
    </Modal>
  );
}
