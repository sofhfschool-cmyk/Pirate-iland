import { BrowserRouter } from "react-router-dom";
import { useEffect, useState } from "react";
import { initializeDatabase } from "./lib/storage";
import { Workspace } from "./Workspace";
import "./App.css";

export default function App() {
  const [ready, setReady] = useState(false), [error, setError] = useState("");
  useEffect(() => { let alive = true; initializeDatabase().then(() => { if (alive) setReady(true); }, e => { if (alive) setError(e instanceof Error ? e.message : "Unable to open the database."); }); return () => { alive = false; }; }, []);
  if (error) return <main className="page-container"><div className="surface empty-state" role="alert"><h2>Unable to load your workspace</h2><p>{error}</p><button className="primary-button" onClick={() => location.reload()}>Try again</button></div></main>;
  if (!ready) return null;
  return (
    <BrowserRouter>
      <Workspace />
    </BrowserRouter>
  );
}
