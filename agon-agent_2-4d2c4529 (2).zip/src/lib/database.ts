import { openDB } from 'idb';
import { builtInPapers, demoAttempts, studentDemo } from './data';
import type { User, Paper, Attempt, Draft } from './types';

export type Account = User & { salt: string; hash: string };
export interface Snapshot { mode: 'shared' | 'device'; user: User | null; papers: Paper[]; attempts: Attempt[]; draft: Draft | null; seen: boolean }
const tables = ['accounts', 'papers', 'attempts', 'drafts', 'settings'] as const;
let opened: ReturnType<typeof openDevice> | undefined;
async function openDevice() {
  const db = await openDB('pi-rate-i-land', 1, { upgrade(db) {
    db.createObjectStore('accounts', { keyPath: 'id' }).createIndex('email', 'email', { unique: true });
    db.createObjectStore('papers', { keyPath: 'id' }).createIndex('position', '_position');
    db.createObjectStore('attempts', { keyPath: 'id' }).createIndex('owner', 'userId');
    db.createObjectStore('drafts', { keyPath: 'userId' });
    db.createObjectStore('settings');
  } });
  // One transaction makes initial seeding and legacy migration restart-safe, including across tabs.
  const tx = db.transaction([...tables], 'readwrite'), settings = tx.objectStore('settings');
  if (!(await settings.get('schema:1'))) {
    const legacy = new Map<string, unknown>(), prefix = 'pirate-iland-v2:';
    for (let i = 0; i < localStorage.length; i++) {
      const k = localStorage.key(i); if (!k?.startsWith(prefix)) continue;
      try { legacy.set(k.slice(prefix.length), JSON.parse(localStorage.getItem(k)!)); } catch { /* Leave malformed legacy records untouched. */ }
    }
    const writes: Promise<unknown>[] = [];
    const overrides = (legacy.get('papers') || []) as Paper[];
    builtInPapers.forEach((p, i) => writes.push(tx.objectStore('papers').put({ ...p, _position: -i })));
    overrides.forEach((p, i) => writes.push(tx.objectStore('papers').put({ ...p, _position: overrides.length - i })));
    for (const a of (legacy.get('accounts') || []) as Account[]) writes.push(tx.objectStore('accounts').put(a));
    for (const a of (legacy.get('attempts') ?? demoAttempts()) as Attempt[]) writes.push(tx.objectStore('attempts').put(a));
    for (const [k, value] of legacy) {
      if (k.startsWith('draft:') && value) writes.push(tx.objectStore('drafts').put(value));
      if (k.startsWith('notices:') || k === 'session') writes.push(settings.put(value, k));
    }
    writes.push(settings.put(true, 'schema:1'), settings.put(overrides.map(p => p.id), 'changed-papers'));
    await Promise.all([...writes, tx.done]);
    // Never delete the old copy until all database writes commit successfully.
    for (const k of legacy.keys()) localStorage.removeItem(prefix + k);
  } else await tx.done;
  return db;
}
export const deviceDatabase = () => opened ??= openDevice().catch(e => { opened = undefined; throw e; });
export async function deviceSnapshot(): Promise<Snapshot> {
  const db = await deviceDatabase(), stored = await db.get('settings', 'session');
  const user: User | null = stored === undefined ? studentDemo : stored;
  const [papers, attempts, draft, seen] = await Promise.all([
    db.getAllFromIndex('papers', 'position'),
    user?.role === 'admin' ? db.getAll('attempts') : user ? db.getAllFromIndex('attempts', 'owner', user.id) : [],
    user ? db.get('drafts', user.id) : null,
    user ? db.get('settings', 'notices:' + user.id) : false,
  ]);
  return { mode: 'device', user, papers: papers.reverse(), attempts: attempts.sort((a, b) => a.finishedAt - b.finishedAt), draft: draft || null, seen: !!seen };
}
export async function request<T>(command?: Record<string, unknown>): Promise<T> {
  const response = await fetch('/api/database', { method: command ? 'POST' : 'GET', credentials: 'same-origin', cache: 'no-store', ...(command ? { headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(command) } : {}), signal: AbortSignal.timeout(15000) });
  // Static-only hosts deliberately use IndexedDB, not an ephemeral server filesystem.
  if (!command && (response.status === 404 || (response.ok && response.headers.get('content-type')?.includes('text/html')))) return { mode: 'device' } as T;
  const result = await response.json();
  if (!response.ok || result.error) throw new Error(result.error || 'Unable to reach the database. Please try again.');
  return result as T;
}
export async function migrateToShared(state: Snapshot) {
  if (!state.user) return state;
  const db = await deviceDatabase(), id = state.user.id, key = `migrated:shared:${id}`;
  if (await db.get('settings', key)) return state;
  const [attempts, draft, seen, changed] = await Promise.all([db.getAllFromIndex('attempts', 'owner', id), db.get('drafts', id), db.get('settings', `notices:${id}`), db.get('settings', 'changed-papers')]);
  const existing = new Set(state.attempts.map(a => a.id));
  // Small independent imports can safely retry without duplicating a result or overwriting a newer edit.
  for (const a of attempts.filter(a => !existing.has(a.id))) await request({ action: 'migrate', attempts: [a] });
  if (state.user.role === 'admin') for (const paperId of changed || []) { const paper = await db.get('papers', paperId); if (paper) await request({ action: 'migrate', papers: [paper] }); }
  if (draft || seen) await request({ action: 'migrate', draft, seen });
  await db.put('settings', true, key);
  return request<Snapshot>();
}
