export type Role = "student" | "admin";
export const levels = [
  "Class VIII",
  "Class IX",
  "Class X",
  "Class XI",
  "Class XII",
  "JEE Main",
] as const;
export type Level = (typeof levels)[number];
export type Subject =
  "Physics" | "Mathematics" | "Chemistry" | "Science" | "Mixed subjects";
export const subjects: Subject[] = [
  "Physics",
  "Mathematics",
  "Chemistry",
  "Science",
  "Mixed subjects",
];
export const subjectClass = (s: Subject) =>
  ({
    Physics: "physics",
    Mathematics: "maths",
    Chemistry: "chemistry",
    Science: "science",
    "Mixed subjects": "mixed",
  })[s];
export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  level: Level;
  demo?: boolean;
}
export interface Question {
  id: string;
  text: string;
  choices: string[];
  correct: number;
  marks: number;
  subject: Subject;
  explanation: string;
}
export interface Paper {
  id: string;
  title: string;
  description: string;
  level: Level;
  subject: Subject;
  minutes: number;
  negative: number;
  questions: Question[];
  published: boolean;
  type: "Chapter test" | "Mock test" | "Practice test";
  source?: string;
}
export interface Attempt {
  id: string;
  userId: string;
  student: string;
  paperId: string;
  title: string;
  level: Level;
  subject: Subject;
  finishedAt: number;
  elapsed: number;
  answers: Record<string, number>;
  questions: Question[];
  negative: number;
  score: number;
  total: number;
  correct: number;
  incorrect: number;
  unanswered: number;
}
export interface Draft {
  userId: string;
  paper: Paper;
  startedAt: number;
  endsAt: number;
  current: number;
  answers: Record<string, number>;
  flagged: string[];
}
export const totalMarks = (paper: Paper) =>
  paper.questions.reduce((n, q) => n + q.marks, 0);
export const percent = (a: Attempt) => Math.round((a.score / a.total) * 100);
export const initials = (name: string) =>
  name
    .trim()
    .split(/\s+/)
    .slice(0, 2)
    .map((x) => x[0]?.toUpperCase())
    .join("");
export const shortDate = (time: number) =>
  new Date(time).toLocaleDateString("en-GB", {
    day: "numeric",
    month: "short",
  });
export function gradeAttempt(
  draft: Draft,
  user: User,
  finishedAt = Date.now(),
): Attempt {
  const { paper, answers } = draft;
  let score = 0,
    correct = 0,
    incorrect = 0,
    unanswered = 0;
  paper.questions.forEach((q) => {
    if (answers[q.id] === undefined) unanswered++;
    else if (answers[q.id] === q.correct) {
      correct++;
      score += q.marks;
    } else {
      incorrect++;
      score -= paper.negative;
    }
  });
  return {
    id: `result-${crypto.randomUUID()}`,
    userId: user.id,
    student: user.name,
    paperId: paper.id,
    title: paper.title,
    level: paper.level,
    subject: paper.subject,
    questions: paper.questions,
    answers,
    finishedAt,
    elapsed: Math.max(
      0,
      Math.min(
        paper.minutes * 60,
        Math.round((finishedAt - draft.startedAt) / 1000),
      ),
    ),
    negative: paper.negative,
    score: Math.round(score * 100) / 100,
    total: totalMarks(paper),
    correct,
    incorrect,
    unanswered,
  };
}
