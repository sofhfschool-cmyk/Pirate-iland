import type { Question, Subject } from "./types";
export const sampleLatex = String.raw`% π-rate i-Land — LaTeX question paper
% Each question needs one \CorrectChoice.
\begin{questions}
\question[4] Find the derivative of $f(x)=x^3$ at $x=2$.
\begin{choices}
  \choice $6$
  \CorrectChoice $12$
  \choice $8$
  \choice $16$
\end{choices}

\question[4] If $A=\begin{pmatrix}2 & 1 \\ 3 & 4\end{pmatrix}$, find $\det(A)$.
\begin{choices}
  \choice $11$
  \choice $8$
  \CorrectChoice $5$
  \choice $-5$
\end{choices}

\question[4] Evaluate $\int_0^1 2x\,dx$.
\begin{choices}
  \CorrectChoice $1$
  \choice $2$
  \choice $0$
  \choice $4$
\end{choices}
\end{questions}`;
export function parseLatex(
  source: string,
  subject: Subject,
): { questions: Question[]; error: string } {
  const text = source.replace(/(?<!\\)%[^\n]*/g, "");
  const parts = text.split(/\\question\b/).slice(1);
  if (!parts.length)
    return {
      questions: [],
      error:
        "Add a \\question followed by a choices environment. The template shows the supported format.",
    };
  if (parts.length > 200)
    return { questions: [], error: "A paper can contain up to 200 questions." };
  const questions: Question[] = [];
  for (let i = 0; i < parts.length; i++) {
    const num = i + 1,
      part = parts[i].trim(),
      m = part.match(
        /^(?:\[([^\]]+)\])?\s*([\s\S]*?)\\begin\{(choices|oneparchoices|checkboxes)\}([\s\S]*?)\\end\{\3\}/,
      );
    if (!m)
      return {
        questions,
        error: `Question ${num}: include a complete \\begin{choices} … \\end{choices} block.`,
      };
    if (!m[2].trim())
      return { questions, error: `Question ${num} has no question text.` };
    const choices = [
      ...m[4].matchAll(
        /\\(CorrectChoice|choice)\b\s*([\s\S]*?)(?=\\(?:CorrectChoice|choice)\b|$)/g,
      ),
    ];
    if (choices.length < 2 || choices.length > 8)
      return {
        questions,
        error: `Question ${num} needs between 2 and 8 choices.`,
      };
    if (choices.filter((c) => c[1] === "CorrectChoice").length !== 1)
      return {
        questions,
        error: `Question ${num}: mark exactly one answer with \\CorrectChoice.`,
      };
    if (choices.some((c) => !c[2].trim()))
      return {
        questions,
        error: `Question ${num} has an empty answer choice.`,
      };
    const marks = m[1] ? Number(m[1]) : 4;
    if (!Number.isFinite(marks) || marks <= 0 || marks > 100)
      return {
        questions,
        error: `Question ${num}: marks must be greater than 0 and at most 100.`,
      };
    const sol = part.match(/\\begin\{solution\}([\s\S]*?)\\end\{solution\}/);
    questions.push({
      id: `q${num}`,
      text: m[2].trim(),
      choices: choices.map((c) => c[2].trim()),
      correct: choices.findIndex((c) => c[1] === "CorrectChoice"),
      marks,
      subject,
      explanation: sol?.[1].trim() || "The correct answer is shown above.",
    });
  }
  return { questions, error: "" };
}
export function downloadFile(
  filename: string,
  content: string,
  type = "text/plain",
) {
  const url = URL.createObjectURL(new Blob([content], { type }));
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  document.body.appendChild(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
}
export function toLatex(questions: Question[]) {
  return `\\begin{questions}\n${questions.map((q) => `\\question[${q.marks}] ${q.text}\n\\begin{choices}\n${q.choices.map((c, i) => `  \\${i === q.correct ? "CorrectChoice" : "choice"} ${c}`).join("\n")}\n\\end{choices}\n\\begin{solution}${q.explanation}\\end{solution}`).join("\n\n")}\n\\end{questions}`;
}
