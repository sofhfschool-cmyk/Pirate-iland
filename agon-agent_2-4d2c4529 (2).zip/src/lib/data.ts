import {
  type Paper,
  type Question,
  type Subject,
  type Level,
  type User,
  type Attempt,
  gradeAttempt,
} from "./types";
export const studentDemo: User = {
  id: "demo-student",
  name: "Aarav Sharma",
  email: "student@pirate.school",
  role: "student",
  level: "Class XII",
  demo: true,
};
export const adminDemo: User = {
  id: "demo-admin",
  name: "Meera Patel",
  email: "admin@pirate.school",
  role: "admin",
  level: "Class XII",
  demo: true,
};
function numeric(
  i: number,
  text: string,
  value: number,
  unit: string,
  subject: Subject,
  explanation: string,
  id: string,
): Question {
  const delta = value < 2 ? 0.2 : Math.max(1, Math.round(Math.abs(value) / 4));
  const correct = (i * 7 + 1) % 4;
  const offsets =
    i % 3 === 0 ? [1, -1, 2] : i % 3 === 1 ? [-1, 2, -2] : [2, -1, 1];
  const options = offsets.map(
    (n) => `${Number((value + n * delta).toFixed(3))}${unit}`,
  );
  options.splice(correct, 0, `${Number(value.toFixed(3))}${unit}`);
  return {
    id: `${id}-${i + 1}`,
    text,
    choices: options,
    correct,
    subject,
    marks: 4,
    explanation,
  };
}
function makeQuestion(topic: string, i: number, id: string): Question {
  const n = i + 2,
    k = Math.floor(i / 3) + 2;
  const q = (
    text: string,
    value: number,
    unit: string,
    subject: Subject,
    explanation: string,
  ) => numeric(i, text, value, unit, subject, explanation, id);
  if (topic === "electro") {
    if (i % 3 === 0)
      return q(
        `A charge of $${k}\\,\\mu\\mathrm{C}$ is placed in a uniform electric field of $3\\times10^5\\,\\mathrm{N/C}$. What is the magnitude of the force on the charge?`,
        k * 0.3,
        " N",
        "Physics",
        `Use $F=qE$. Converting the charge to coulombs gives $F=${k}\\times10^{-6}\\times3\\times10^5=${Number((k * 0.3).toFixed(1))}\\,\\mathrm{N}$.`,
      );
    if (i % 3 === 1)
      return q(
        `A $${k}\\,\\mu\\mathrm{F}$ capacitor is connected across a $12\\,\\mathrm{V}$ battery. What charge does it store?`,
        k * 12,
        " μC",
        "Physics",
        `The stored charge is $Q=CV=${k}\\times12=${k * 12}\\,\\mu\\mathrm{C}$.`,
      );
    return q(
      `Moving a $${k}\\,\\mathrm{C}$ test charge between two points requires $${k * n}\\,\\mathrm{J}$ of work. Find the magnitude of the potential difference.`,
      n,
      " V",
      "Physics",
      `Potential difference is work per unit charge: $V=W/q=${k * n}/${k}=${n}\\,\\mathrm{V}$.`,
    );
  }
  if (topic === "matrices") {
    if (i % 3 === 0)
      return q(
        `Find the determinant of the matrix $A=\\begin{pmatrix}${k} & 1 \\\\ 2 & ${k + 1}\\end{pmatrix}$.`,
        k * (k + 1) - 2,
        "",
        "Mathematics",
        `For a $2\\times2$ matrix, $\\det(A)=ad-bc=${k}(${k + 1})-2=${k * (k + 1) - 2}$.`,
      );
    if (i % 3 === 1)
      return q(
        `If $A=\\begin{pmatrix}${n} & 2 \\\\ 0 & ${k}\\end{pmatrix}$, what is the trace of $A$?`,
        n + k,
        "",
        "Mathematics",
        `The trace is the sum of the diagonal elements: $${n}+${k}=${n + k}$.`,
      );
    return q(
      `A square matrix $A$ of order 2 has $\\det(A)=${k}$. Find $\\det(3A)$.`,
      9 * k,
      "",
      "Mathematics",
      `For an $n\\times n$ matrix, $\\det(cA)=c^n\\det(A)$. Here $3^2\\times${k}=${9 * k}$.`,
    );
  }
  if (topic === "atomic") {
    if (i % 3 === 0)
      return q(
        `An atom has atomic number $${n}$ and mass number $${2 * n + 1}$. How many neutrons does its nucleus contain?`,
        n + 1,
        "",
        "Chemistry",
        `Neutron count is mass number minus atomic number: $${2 * n + 1}-${n}=${n + 1}$.`,
      );
    if (i % 3 === 1)
      return q(
        `A sample contains $${k}$ moles of helium. Find its mass, taking the molar mass of helium as $4\\,\\mathrm{g/mol}$.`,
        4 * k,
        " g",
        "Chemistry",
        `Mass equals amount times molar mass: $m=nM=${k}\\times4=${4 * k}\\,\\mathrm{g}$.`,
      );
    return q(
      `How many moles are present in $${18 * k}\\,\\mathrm{g}$ of water? Use $M(\\mathrm{H_2O})=18\\,\\mathrm{g/mol}$.`,
      k,
      " mol",
      "Chemistry",
      `Use $n=m/M=${18 * k}/18=${k}\\,\\mathrm{mol}$.`,
    );
  }
  if (topic === "force") {
    if (i % 2 === 0)
      return q(
        `A force of $${n * 20}\\,\\mathrm{N}$ acts normally on a surface of area $${n}\\,\\mathrm{m^2}$. Calculate the pressure.`,
        20,
        " Pa",
        "Science",
        `Pressure is force per unit area: $P=F/A=${n * 20}/${n}=20\\,\\mathrm{Pa}$.`,
      );
    return q(
      `A box experiences a force of $${n * 5}\\,\\mathrm{N}$ to the right and $${n * 2}\\,\\mathrm{N}$ to the left. Find the magnitude of the resultant force.`,
      n * 3,
      " N",
      "Science",
      `The forces are opposite, so their magnitudes subtract: $${n * 5}-${n * 2}=${n * 3}\\,\\mathrm{N}$.`,
    );
  }
  if (topic === "motion") {
    if (i % 2 === 0)
      return q(
        `A cyclist travels $${n * 6}\\,\\mathrm{m}$ in $6\\,\\mathrm{s}$ at constant speed. Find the speed.`,
        n,
        " m/s",
        "Physics",
        `Speed is distance divided by time: $v=${n * 6}/6=${n}\\,\\mathrm{m/s}$.`,
      );
    return q(
      `A body starts from rest and accelerates uniformly at $${k}\\,\\mathrm{m/s^2}$ for $4\\,\\mathrm{s}$. What is its final speed?`,
      4 * k,
      " m/s",
      "Physics",
      `From $v=u+at$, we get $v=0+${k}\\times4=${4 * k}\\,\\mathrm{m/s}$.`,
    );
  }
  if (topic === "quadratic") {
    if (i % 2 === 0)
      return q(
        `What is the sum of the roots of $x^2-${n + 3}x+${n * 3}=0$?`,
        n + 3,
        "",
        "Mathematics",
        `For $ax^2+bx+c=0$, the sum of the roots is $-b/a=${n + 3}$.`,
      );
    return q(
      `Find the larger root of $x^2-${n + 1}x+${n}=0$.`,
      n,
      "",
      "Mathematics",
      `Factor the expression as $(x-1)(x-${n})=0$. The larger root is $${n}$.`,
    );
  }
  if (topic === "trig")
    return q(
      `If $\\sin\\theta=\\frac{3}{5}$ and $\\theta$ is acute, find $${n * 5}\\cos\\theta$.`,
      n * 4,
      "",
      "Mathematics",
      `Using $\\cos^2\\theta=1-\\sin^2\\theta$, we get $\\cos\\theta=4/5$. Thus the result is $${n * 5}\\times4/5=${n * 4}$.`,
    );
  if (topic === "calculus")
    return q(
      `For $f(x)=${k}x^2+${n}x$, evaluate $f'(2)$.`,
      4 * k + n,
      "",
      "Mathematics",
      `Differentiate term by term: $f'(x)=${2 * k}x+${n}$. At $x=2$, this is $${4 * k + n}$.`,
    );
  return q(
    `Solve for $x$: $${k}x+${k + 1}=${k * n + k + 1}$.`,
    n,
    "",
    "Mathematics",
    `Subtract $${k + 1}$ from both sides, then divide by $${k}$ to obtain $x=${n}$.`,
  );
}
const defs: [string, string, string, Level, Subject, number, string][] = [
  [
    "electrostatics",
    "Electrostatics",
    "Charges, electric fields, and potential.",
    "Class XII",
    "Physics",
    45,
    "electro",
  ],
  [
    "matrices",
    "Matrices & Determinants",
    "Matrix operations and their applications.",
    "Class XII",
    "Mathematics",
    60,
    "matrices",
  ],
  [
    "atomic",
    "Atoms & Mole Calculations",
    "Build confidence in the fundamentals.",
    "Class XI",
    "Chemistry",
    40,
    "atomic",
  ],
  [
    "force",
    "Force & Pressure",
    "Explore forces in everyday life.",
    "Class VIII",
    "Science",
    35,
    "force",
  ],
  [
    "motion",
    "Motion & Acceleration",
    "Speed, velocity, and equations of motion.",
    "Class IX",
    "Physics",
    40,
    "motion",
  ],
  [
    "quadratics",
    "Quadratic Equations",
    "Roots, factors, and quadratic expressions.",
    "Class X",
    "Mathematics",
    45,
    "quadratic",
  ],
  [
    "algebra",
    "Linear Equations",
    "Strengthen your algebra fundamentals.",
    "Class VIII",
    "Mathematics",
    30,
    "algebra",
  ],
  [
    "trig",
    "Trigonometric Functions",
    "Identities and trigonometric ratios.",
    "Class XI",
    "Mathematics",
    45,
    "trig",
  ],
  [
    "calculus",
    "Differential Calculus",
    "Derivatives and their applications.",
    "JEE Main",
    "Mathematics",
    50,
    "calculus",
  ],
];
export const builtInPapers: Paper[] = defs.map(
  ([id, title, description, level, subject, minutes, topic]) => ({
    id,
    title,
    description,
    level,
    subject,
    minutes,
    negative: 0,
    published: true,
    type: "Chapter test",
    questions: Array.from({ length: 25 }, (_, i) => makeQuestion(topic, i, id)),
  }),
);
export const featuredPaper: Paper = {
  id: "jee-mock-01",
  title: "JEE Main Mock Test 01",
  description:
    "A full-length practice paper in Physics, Chemistry, and Mathematics.",
  level: "JEE Main",
  subject: "Mixed subjects",
  minutes: 180,
  negative: 1,
  published: true,
  type: "Mock test",
  questions: Array.from({ length: 75 }, (_, i) =>
    makeQuestion(
      i < 25
        ? i % 2
          ? "motion"
          : "electro"
        : i < 50
          ? "atomic"
          : i % 2
            ? "matrices"
            : "calculus",
      i,
      "jee-mock-01",
    ),
  ),
};
builtInPapers.push(featuredPaper);
export function demoAttempts(): Attempt[] {
  const offsets = [26, 21, 16, 11, 6, 2],
    counts = [17, 21, 19, 22, 20, 24],
    papers = [1, 0, 2, 1, 2, 0];
  return offsets.map((days, idx) => {
    const paper = builtInPapers[papers[idx]],
      finishedAt = Date.now() - days * 86400000,
      answers: Record<string, number> = {};
    paper.questions.forEach((q, i) => {
      if (i < counts[idx]) answers[q.id] = q.correct;
      else if (i < 24) answers[q.id] = (q.correct + 1) % 4;
    });
    return {
      ...gradeAttempt(
        {
          userId: studentDemo.id,
          paper,
          startedAt: finishedAt - (22 + idx) * 60000,
          endsAt: finishedAt,
          current: 24,
          answers,
          flagged: [],
        },
        studentDemo,
        finishedAt,
      ),
      id: `demo-result-${idx + 1}`,
    };
  });
}
