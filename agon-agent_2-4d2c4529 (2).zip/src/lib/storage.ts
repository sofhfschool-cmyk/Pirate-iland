import { adminDemo, studentDemo } from './data';
import { deviceDatabase, deviceSnapshot, migrateToShared, request, type Account, type Snapshot } from './database';
import { gradeAttempt, type Attempt, type Draft, type Level, type Paper, type Role, type User } from './types';

// Components read an in-memory snapshot; every durable mutation goes through a database transaction.
let state: Snapshot = { mode: 'device', user: null, papers: [], attempts: [], draft: null, seen: false };
let ready: Promise<void> | undefined, work: Promise<unknown> = Promise.resolve();
const listeners = new Set<() => void>();
const channel = typeof BroadcastChannel !== 'undefined' ? new BroadcastChannel('pi-rate-database') : null;
export const getSnapshot = () => state;
export const subscribe = (fn: () => void) => { listeners.add(fn); return () => { listeners.delete(fn); }; };
function publish(next: Snapshot, broadcast = false) { state = next; listeners.forEach(fn => fn()); if (broadcast) channel?.postMessage('committed'); }
function serial<T>(task: () => Promise<T>) { const pending = work.then(task, task); work = pending.catch(() => undefined); return pending; }
export const isSharedDatabase = () => state.mode === 'shared';
export async function refreshDatabase() {
  return serial(async () => { const next = isSharedDatabase() ? await request<Snapshot>() : await deviceSnapshot(); if (!Array.isArray(next.papers)) throw new Error('The shared database is unavailable. Please try again.'); publish(next); });
}
export function initializeDatabase() {
  return ready ??= (async () => {
    const remote = await request<Snapshot>();
    const next = remote.mode === 'shared' ? await migrateToShared(remote) : await deviceSnapshot();
    publish(next);
    const refresh = () => { void refreshDatabase().catch(e => window.dispatchEvent(new CustomEvent('database-error', { detail: e.message }))); };
    if (channel) channel.onmessage = refresh;
    window.addEventListener('focus', refresh);
  })().catch(e => { ready = undefined; throw e; });
}
export function read<T>(key: string, fallback: T): T { return key === `notices:${state.user?.id}` ? state.seen as T : fallback; }
export async function markRead() {
  return serial(async () => {
    if (!state.user) return;
    if (isSharedDatabase()) await request({ action: 'seen' });
    else await (await deviceDatabase()).put('settings', true, 'notices:' + state.user.id);
    publish({ ...state, seen: true }, true);
  });
}
async function digest(password: string, salt: string) {
  const enc = new TextEncoder(), key = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveBits']);
  const hash = await crypto.subtle.deriveBits({ name: 'PBKDF2', salt: enc.encode(salt), iterations: 100000, hash: 'SHA-256' }, key, 256);
  return Array.from(new Uint8Array(hash), b => b.toString(16).padStart(2, '0')).join('');
}
async function localSession(user: User | null) {
  await (await deviceDatabase()).put('settings', user, 'session');
  publish(await deviceSnapshot(), true);
}
async function sharedSession(command: Record<string, unknown>): Promise<User> {
  const next = await migrateToShared(await request<Snapshot>(command));
  if (!next.user) throw new Error('Unable to open the account. Please sign in again.');
  publish(next, true); return next.user;
}
export function loginDemo(user: User): Promise<User> {
  return serial(async () => { if (isSharedDatabase()) return sharedSession({ action: 'demo', role: user.role }); await localSession(user); return user; });
}
export function login(email: string, password: string, role: Role): Promise<User> {
  return serial(async () => {
    const e = email.trim().toLowerCase(), db = await deviceDatabase(), account: Account | undefined = await db.getFromIndex('accounts', 'email', e);
    if (isSharedDatabase()) return sharedSession({ action: 'login', email: e, password, role, ...(account ? { legacyAccount: account } : {}) });
    const demo = role === 'admin' ? adminDemo : studentDemo;
    if (e === demo.email && password === (role === 'admin' ? 'Admin@123' : 'Student@123')) { await localSession(demo); return demo; }
    if (!account || account.role !== role || (await digest(password, account.salt)) !== account.hash) throw new Error('The email or password is incorrect for this account type.');
    const user: User = { id: account.id, name: account.name, email: e, role, level: account.level };
    await localSession(user); return user;
  });
}
export function signup(name: string, email: string, password: string, level: Level): Promise<User> {
  return serial(async () => {
    const e = email.trim().toLowerCase();
    if (isSharedDatabase()) return sharedSession({ action: 'signup', name, email: e, password, level });
    const db = await deviceDatabase();
    if (await db.getFromIndex('accounts', 'email', e) || [adminDemo.email, studentDemo.email].includes(e)) throw new Error('This email already has an account. Please sign in.');
    if (password.length < 8) throw new Error('Choose a password with at least 8 characters.');
    const user: User = { id: crypto.randomUUID(), name: name.trim(), email: e, level, role: 'student' }, salt = crypto.randomUUID(), hash = await digest(password, salt);
    const tx = db.transaction(['accounts', 'settings'], 'readwrite');
    await Promise.all([tx.objectStore('accounts').add({ ...user, salt, hash }), tx.objectStore('settings').put(user, 'session'), tx.done]);
    publish(await deviceSnapshot(), true); return user;
  });
}
export function signOut() { return serial(async () => { if (isSharedDatabase()) publish(await request<Snapshot>({ action: 'logout' }), true); else await localSession(null); }); }
export function persistPaper(paper: Paper | string) {
  return serial(async () => {
    if (state.user?.role !== 'admin') throw new Error('Administrator access is required.');
    const deleting = typeof paper === 'string', id = deleting ? paper : paper.id;
    if (isSharedDatabase()) await request(deleting ? { action: 'delete-paper', id } : { action: 'paper', paper });
    else {
      const db = await deviceDatabase(), tx = db.transaction(['papers', 'settings'], 'readwrite'), store = tx.objectStore('papers');
      if (deleting) await store.delete(id); else { const old = await store.get(id); await store.put({ ...paper, _position: old?._position ?? Date.now() }); }
      const ids = new Set<string>(await tx.objectStore('settings').get('changed-papers') || []);
      if (deleting) ids.delete(id); else ids.add(id);
      await tx.objectStore('settings').put([...ids], 'changed-papers'); await tx.done;
    }
    const papers = deleting ? state.papers.filter(p => p.id !== id) : state.papers.some(p => p.id === id) ? state.papers.map(p => p.id === id ? paper : p) : [paper, ...state.papers];
    publish({ ...state, papers }, true);
  });
}
async function writeDraft(draft: Draft) {
  if (isSharedDatabase()) await request({ action: 'draft', draft });
  else await (await deviceDatabase()).put('drafts', draft);
}
export function persistDraft(draft: Draft) {
  if (state.user?.id !== draft.userId) return Promise.reject(new Error('Please sign in to save this test.'));
  const previous = state.draft;
  // Keep answer selection and navigation immediate while ordered writes commit.
  publish({ ...state, draft });
  return serial(async () => {
    try { await writeDraft(draft); channel?.postMessage('committed'); }
    catch (error) { if (state.draft === draft) publish({ ...state, draft: previous }); throw error; }
  });
}
export function submitAttempt(draft: Draft, user: User): Promise<Attempt> {
  return serial(async () => {
    if (state.user?.id !== user.id) throw new Error('Please sign in to submit your test.');
    const id = `result-${user.id}-${draft.startedAt}`;
    let attempt: Attempt;
    if (isSharedDatabase()) {
      // Retry-safe: the server commits the result and removes the saved test together.
      attempt = (await request<{ attempt: Attempt }>({ action: 'submit', id })).attempt;
    } else {
      const db = await deviceDatabase(), tx = db.transaction(['attempts', 'drafts'], 'readwrite');
      const old = await tx.objectStore('attempts').get(id), saved: Draft | undefined = await tx.objectStore('drafts').get(user.id);
      if (!old && saved?.startedAt !== draft.startedAt) { tx.abort(); await tx.done.catch(() => undefined); throw new Error('This saved test has changed. Reopen it before submitting.'); }
      attempt = old ?? { ...gradeAttempt(saved!, user, Math.min(Date.now(), saved!.endsAt)), id };
      await tx.objectStore('attempts').put(attempt);
      if (saved?.startedAt === draft.startedAt) await tx.objectStore('drafts').delete(user.id);
      await tx.done;
    }
    publish({ ...state, attempts: [...state.attempts.filter(a => a.id !== id), attempt], draft: null }, true);
    return attempt;
  });
}
