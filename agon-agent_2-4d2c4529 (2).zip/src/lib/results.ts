import { type Attempt, percent } from "./types";
import { downloadFile } from "./latex";
export function exportResults(attempts: Attempt[]) {
  const quote = (value: unknown) =>
    `"${(typeof value === "string" ? value.replace(/^[=+@-]/, "'$&") : String(value)).replace(/"/g, '""')}"`;
  const rows = [
    [
      "Student",
      "Test",
      "Level",
      "Subject",
      "Date",
      "Score",
      "Total",
      "Percentage",
      "Correct",
      "Incorrect",
      "Unanswered",
      "Duration (s)",
    ],
    ...attempts.map((a) => [
      a.student,
      a.title,
      a.level,
      a.subject,
      new Date(a.finishedAt).toISOString(),
      a.score,
      a.total,
      percent(a),
      a.correct,
      a.incorrect,
      a.unanswered,
      a.elapsed,
    ]),
  ];
  downloadFile(
    "pi-rate-i-land-results.csv",
    rows.map((row) => row.map(quote).join(",")).join("\n"),
    "text/csv;charset=utf-8",
  );
}
