"""Browser acceptance tests. Build first, then run: python scripts/smoke_test.py.
Serves the build through Playwright routing; no background server is required.
"""
from pathlib import Path
from urllib.parse import urlparse, unquote
import mimetypes
from playwright.sync_api import sync_playwright, expect

DIST = Path('dist').resolve()
BASE = 'http://localhost:4759'

def serve(route):
    resource = (DIST / unquote(urlparse(route.request.url).path).lstrip('/')).resolve()
    if not resource.is_relative_to(DIST):
        route.abort()
        return
    if not resource.is_file():
        resource = DIST / 'index.html'
    route.fulfill(status=200, path=str(resource), content_type=mimetypes.guess_type(resource.name)[0] or 'application/octet-stream')

def run():
    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True, args=['--no-sandbox'])
        page = browser.new_page(viewport={'width': 1365, 'height': 900}, accept_downloads=True)
        # Exercise only this application's assets, not the preview host's instrumentation.
        page.route('**/*', lambda route: serve(route) if route.request.url.startswith(BASE + '/') else route.fulfill(status=200, content_type='application/javascript', body=''))
        errors = []
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.set_default_timeout(7000)
        go = lambda path: page.goto(BASE + path, wait_until='networkidle')
        button = lambda name: page.get_by_role('button', name=name, exact=True)
        go('/')
        expect(page.locator('h1')).to_contain_text('Welcome back, Aarav')
        expect(page.locator('.score-row > strong')).to_have_text('82%')
        for level in ['Class VIII', 'Class IX', 'Class X', 'Class XI', 'Class XII', 'JEE Main']:
            button(level).click()
            assert page.locator('.test-card').count() > 0
            expect(page.locator('.test-type span').first).to_have_text(level)
        button('All levels').click()
        page.get_by_label('Performance time range').select_option('7')
        expect(page.locator('.performance-stats strong').first).to_have_text('02')
        page.get_by_label('Performance time range').select_option('30')
        button('Notifications').click()
        button('Mark all as read').click()
        expect(page.locator('.notice-empty')).to_contain_text("all caught up")
        page.keyboard.press('Escape')
        print('PASS dashboard, class filters, real analytics filters, notifications')
        button('Start test').first.click()
        button('Begin test').click()
        expect(page.locator('.number-grid button')).to_have_count(25)
        page.get_by_role('radio').nth(1).click()
        button('Mark for review').click()
        button('Save & next').click()
        button('Save & exit').click()
        page.get_by_role('dialog').get_by_role('button', name='Save & exit').click()
        page.locator('.resume-strip a').click()
        page.reload(wait_until='networkidle')
        expect(page.locator('.question-heading')).to_contain_text('02')
        page.get_by_label('Question 1, answered, marked for review', exact=True).click()
        expect(page.get_by_role('radio').nth(1)).to_have_attribute('aria-checked', 'true')
        button('Submit test').click()
        button('Confirm submission').click()
        expect(page.locator('.result-score h2')).to_have_text('4 / 100')
        page.get_by_label('Filter answer review').select_option('Correct')
        expect(page.locator('.review-item')).to_have_count(1)
        page.locator('.review-row').click()
        expect(page.locator('.solution')).to_be_visible()
        go('/analytics')
        expect(page.locator('.metric strong').first).to_have_text('07')
        with page.expect_download() as exported:
            button('Export results').click()
        assert exported.value.suggested_filename.endswith('.csv')
        print('PASS timed exam, saved answers, flags, resume, grading, review, CSV export')
        go('/admin')
        expect(page.locator('h2')).to_contain_text('Admin sign in')
        page.get_by_label('Email address').fill('admin@pirate.school')
        page.locator('input[autocomplete="current-password"]').fill('not-the-password')
        button('Sign in').click()
        expect(page.get_by_role('alert')).to_contain_text('incorrect')
        page.locator('input[autocomplete="current-password"]').fill('Admin@123')
        button('Sign in').click()
        expect(page.locator('h1')).to_contain_text('Welcome back, Meera')
        button('Upload LaTeX').click()
        page.get_by_label('Upload LaTeX question paper', exact=True).set_input_files({'name': 'Algebra sprint.tex', 'mimeType': 'text/x-tex', 'buffer': b'\\begin{questions}\n\\question[4] Find $2+3$.\n\\begin{choices}\n\\choice $4$\n\\CorrectChoice $5$\n\\choice $6$\n\\end{choices}\n\\begin{solution}Adding gives $5$.\\end{solution}\n\\question[4] Find $3^2$.\n\\begin{choices}\n\\CorrectChoice $9$\n\\choice $6$\n\\end{choices}\n\\end{questions}'})
        page.get_by_label('Level', exact=True).select_option('Class VIII')
        page.get_by_label('Duration (min)').fill('5')
        expect(page.locator('.parse-state')).to_contain_text('2 questions parsed · 8 total marks')
        button('Preview').click()
        expect(page.locator('.preview-question')).to_have_count(2)
        expect(page.locator('.paper-preview .katex').first).to_be_visible()
        button('Publish paper').click()
        expect(page.locator('.admin-paper-table')).to_contain_text('Algebra sprint')
        page.get_by_label('Unpublish Algebra sprint', exact=True).click()
        row = page.locator('tr').filter(has_text='Algebra sprint')
        expect(row).to_contain_text('Draft')
        page.get_by_label('Publish Algebra sprint', exact=True).click()
        expect(row).to_contain_text('Published')
        print('PASS admin access guard, password login, .tex file import, KaTeX preview, publishing')
        go('/login?role=student')
        button('Create an account').click()
        page.get_by_label('Full name').fill('Riya Test')
        page.get_by_label('Learning level').select_option('Class VIII')
        page.get_by_label('Email address').fill('riya@example.edu')
        page.locator('input[autocomplete="new-password"]').fill('Learning123!')
        button('Create student account').click()
        expect(page.locator('h1')).to_contain_text('Riya')
        expect(page.locator('.empty-chart')).to_be_visible()
        go('/library')
        page.get_by_label('Search tests').fill('Algebra sprint')
        expect(page.locator('.test-card')).to_have_count(1)
        button('Start test').click()
        button('Begin test').click()
        page.get_by_role('radio').nth(1).click()
        button('Save & next').click()
        page.get_by_role('radio').first.click()
        button('Review & submit').click()
        button('Confirm submission').click()
        expect(page.locator('.result-score h2')).to_have_text('8 / 8')
        expect(page.locator('.score-ring strong')).to_have_text('100%')
        go('/analytics')
        expect(page.locator('.metric strong').first).to_have_text('01')
        go('/results/demo-result-1')
        expect(page.locator('h1')).to_have_text('My analytics')
        print('PASS new student signup, account-isolated analytics, uploaded test, correct marks')
        go('/')
        button('Start mock test').click()
        button('Begin test').click()
        expect(page.locator('.number-grid button')).to_have_count(75)
        page.get_by_role('radio').first.click()
        page.evaluate("""() => new Promise((resolve, reject) => {const open=indexedDB.open('pi-rate-i-land');open.onsuccess=()=>{const db=open.result;const tx=db.transaction(['drafts','settings'],'readwrite');const session=tx.objectStore('settings').get('session');session.onsuccess=()=>{const store=tx.objectStore('drafts'),r=store.get(session.result.id);r.onsuccess=()=>store.put({...r.result,endsAt:Date.now()-1})};tx.oncomplete=()=>{db.close();resolve()};tx.onerror=()=>reject(tx.error)}})""")
        page.reload(wait_until='networkidle')
        expect(page.locator('.result-score h2')).to_have_text('-1 / 300')
        print('PASS mock paper count, negative marking, time-up auto-submission')
        button('Open account menu').click()
        button('Sign out').click()
        page.wait_for_url('**/login')  # Wait for the sign-out transaction to finish.
        go('/analytics')
        expect(page.locator('h2')).to_contain_text('Welcome back')
        page.get_by_label('Email address').fill('riya@example.edu')
        page.locator('input[autocomplete="current-password"]').fill('Learning123!')
        button('Sign in').click()
        expect(page.locator('h1')).to_contain_text('Riya')
        for width in [360, 390, 600, 768, 1024, 1440]:
            page.set_viewport_size({'width':width,'height':844})
            for route in ['/', '/library', '/analytics']:
                go(route)
                assert page.evaluate('document.documentElement.scrollWidth <= innerWidth + 1'), f'Overflow on {route} at {width}px'
        assert not errors, errors
        print('PASS saved login, sign-out protection, six responsive widths, no browser errors')
        browser.close()

if __name__ == '__main__':
    run()
