export { handleDatabase as default } from '../server/database';
