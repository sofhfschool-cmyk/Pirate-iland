import type { IncomingMessage, ServerResponse } from 'node:http';
import { createHash, randomBytes, randomUUID, pbkdf2, timingSafeEqual } from 'node:crypto';
import { promisify } from 'node:util';
import { mkdir } from 'node:fs/promises';
import { dirname, resolve } from 'node:path';
import { createClient, type Client, type InStatement } from '@libsql/client';
import { adminDemo, studentDemo, builtInPapers, demoAttempts } from '../src/lib/data';
import { gradeAttempt, levels, type User, type Draft, type Paper, type Attempt } from '../src/lib/types';

// Only this server module has access to the SQL connection and password hashes.
const hashPassword = promisify(pbkdf2);
const COOKIE = 'pirate_database_session';
const lifetime = 30 * 86400000;
let connection: Promise<Client> | undefined;
class RequestError extends Error { readonly status: number; constructor(message: string, status = 400) { super(message); this.status = status; } }
function fail(message: string, status = 400): never { throw new RequestError(message, status); }
const hashToken = (s: string) => createHash('sha256').update(s).digest('hex');
const encode = JSON.stringify;
const decode = <T,>(value: unknown): T => JSON.parse(String(value)) as T;
const profile = (u: User): User => ({ id: u.id, name: u.name, email: u.email, level: u.level, role: u.role, ...(u.demo ? { demo: true } : {}) });
type Account = User & { salt: string; hash: string };
interface Command { action?: string; email?: string; password?: string; role?: string; name?: string; level?: User['level']; id?: string; paper?: Paper; draft?: Draft; legacyAccount?: Account; papers?: Paper[]; attempts?: Attempt[]; seen?: boolean }

async function openDatabase() {
  const remote = process.env.TURSO_DATABASE_URL;
  const file = resolve(process.env.SQLITE_PATH || '.data/pi-rate-i-land.sqlite');
  if (!remote) await mkdir(dirname(file), { recursive: true });
  const db = createClient({ url: remote || `file:${file}`, authToken: process.env.TURSO_AUTH_TOKEN });
  // The same schema and atomic batches are used on disk and on hosted libSQL.
  await db.batch([
    'CREATE TABLE IF NOT EXISTS accounts (id TEXT PRIMARY KEY, email TEXT NOT NULL UNIQUE COLLATE NOCASE, profile TEXT NOT NULL, salt TEXT NOT NULL, hash TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES accounts(id), expires INTEGER NOT NULL)',
    'CREATE INDEX IF NOT EXISTS session_expiry ON sessions(expires)',
    'CREATE TABLE IF NOT EXISTS papers (id TEXT PRIMARY KEY, published INTEGER NOT NULL, position INTEGER NOT NULL, data TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS attempts (id TEXT PRIMARY KEY, owner TEXT NOT NULL REFERENCES accounts(id), finished INTEGER NOT NULL, data TEXT NOT NULL)',
    'CREATE INDEX IF NOT EXISTS student_history ON attempts(owner, finished)',
    'CREATE TABLE IF NOT EXISTS drafts (owner TEXT PRIMARY KEY REFERENCES accounts(id), data TEXT NOT NULL)',
    'CREATE TABLE IF NOT EXISTS notices (owner TEXT PRIMARY KEY REFERENCES accounts(id), seen INTEGER NOT NULL)',
    'CREATE TABLE IF NOT EXISTS schema_migrations (version INTEGER PRIMARY KEY)',
  ], 'write');
  if (!(await db.execute('SELECT 1 FROM schema_migrations WHERE version = 1')).rows.length) {
    const seed: InStatement[] = [];
    for (const u of [studentDemo, adminDemo]) {
      const salt = randomUUID(), password = u.role === 'admin' ? (process.env.PIRATE_ADMIN_PASSWORD || 'Admin@123') : 'Student@123';
      const hash = (await hashPassword(password, salt, 100000, 32, 'sha256')).toString('hex');
      seed.push({ sql: 'INSERT OR IGNORE INTO accounts VALUES(?,?,?,?,?)', args: [u.id, u.email, encode(u), salt, hash] });
    }
    builtInPapers.forEach((p, i) => seed.push({ sql: 'INSERT OR IGNORE INTO papers VALUES(?,?,?,?)', args: [p.id, Number(p.published), -i, encode(p)] }));
    for (const a of demoAttempts()) seed.push({ sql: 'INSERT OR IGNORE INTO attempts VALUES(?,?,?,?)', args: [a.id, a.userId, a.finishedAt, encode(a)] });
    await db.batch([...seed, 'INSERT OR IGNORE INTO schema_migrations VALUES(1)'], 'write');
  }
  return db;
}
async function database() {
  connection ??= openDatabase().catch(e => { connection = undefined; throw e; });
  return connection;
}
async function readBody(req: IncomingMessage & { body?: unknown }): Promise<Command> {
  let raw = req.body;
  if (raw === undefined) {
    const chunks: Buffer[] = []; let length = 0;
    for await (const chunk of req) { const b = Buffer.from(chunk); length += b.length; if (length > 3800000) fail('This paper is too large.', 413); chunks.push(b); }
    raw = Buffer.concat(chunks).toString('utf8');
  }
  if (typeof raw === 'string' || Buffer.isBuffer(raw)) { try { raw = JSON.parse(String(raw)); } catch { fail('Invalid database request.'); } }
  if (!raw || typeof raw !== 'object' || Array.isArray(raw)) fail('Invalid database request.');
  return raw as Command;
}
function validPaper(p: Paper | undefined): p is Paper {
  return !!p && typeof p.id === 'string' && p.id.length <= 150 && typeof p.title === 'string' && !!p.title.trim() && p.title.length <= 90 && levels.includes(p.level) && typeof p.published === 'boolean' && Number.isFinite(p.minutes) && p.minutes >= 1 && p.minutes <= 360 && Number.isFinite(p.negative) && p.negative >= 0 && p.negative <= 10 && Array.isArray(p.questions) && p.questions.length > 0 && p.questions.length <= 200 && p.questions.every(q => q && typeof q.id === 'string' && typeof q.text === 'string' && Array.isArray(q.choices) && q.choices.length >= 2 && q.choices.length <= 8 && q.choices.every(c => typeof c === 'string') && Number.isInteger(q.correct) && q.correct >= 0 && q.correct < q.choices.length && Number.isFinite(q.marks) && q.marks > 0 && q.marks <= 100);
}
async function snapshot(db: Client, user: User | null) {
  if (!user) return { mode: 'shared', user: null, papers: [], attempts: [], draft: null, seen: false };
  const [papers, attempts, draft, notice] = await db.batch([
    `SELECT data FROM papers ${user.role === 'admin' ? '' : 'WHERE published=1'} ORDER BY position DESC`,
    user.role === 'admin' ? 'SELECT data FROM attempts ORDER BY finished' : { sql: 'SELECT data FROM attempts WHERE owner=? ORDER BY finished', args: [user.id] },
    { sql: 'SELECT data FROM drafts WHERE owner=?', args: [user.id] },
    { sql: 'SELECT seen FROM notices WHERE owner=?', args: [user.id] },
  ], 'read');
  return { mode: 'shared', user, papers: papers.rows.map(r => decode<Paper>(r.data)), attempts: attempts.rows.map(r => decode<Attempt>(r.data)), draft: draft.rows[0] ? decode<Draft>(draft.rows[0].data) : null, seen: !!notice.rows[0]?.seen };
}
export async function handleDatabase(req: IncomingMessage & { body?: unknown }, res: ServerResponse) {
  res.setHeader('Cache-Control', 'no-store, private');
  res.setHeader('Content-Type', 'application/json; charset=utf-8');
  res.setHeader('Vary', 'Cookie');
  const send = (data: unknown) => res.end(encode(data));
  try {
    // A serverless /tmp file is NOT a durable database. Never use one as a fallback.
    if (process.env.VERCEL && !process.env.TURSO_DATABASE_URL) { send({ mode: 'device' }); return; }
    if (req.method !== 'GET' && req.method !== 'POST') fail('Method not allowed.', 405);
    if (req.method === 'POST') {
      if (!req.headers['content-type']?.startsWith('application/json')) fail('JSON required.', 415);
      if (req.headers.origin && new URL(req.headers.origin).host !== req.headers.host && new URL(req.headers.origin).host !== req.headers['x-forwarded-host']) fail('Invalid request origin.', 403);
    }
    const db = await database();
    const cmd: Command = req.method === 'GET' ? { action: 'state' } : await readBody(req);
    const token = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith(COOKIE + '='))?.slice(COOKIE.length + 1);
    const existing = token && token !== 'signed-out' ? (await db.execute({ sql: 'SELECT a.profile FROM sessions s JOIN accounts a ON s.owner=a.id WHERE s.token=? AND s.expires>?', args: [hashToken(token), Date.now()] })).rows[0] : undefined;
    let user: User | null = existing ? decode<User>(existing.profile) : null;
    const cookie = (value: string) => res.setHeader('Set-Cookie', `${COOKIE}=${value}; Path=/api/database; HttpOnly; SameSite=Lax; Max-Age=${lifetime / 1000}${process.env.VERCEL || req.headers['x-forwarded-proto'] === 'https' ? '; Secure' : ''}`);
    async function signIn(u: User) {
      const fresh = randomBytes(32).toString('hex');
      await db.batch([{ sql: 'DELETE FROM sessions WHERE token=? OR expires<=?', args: [hashToken(token || ''), Date.now()] }, { sql: 'INSERT INTO sessions VALUES(?,?,?)', args: [hashToken(fresh), u.id, Date.now() + lifetime] }], 'write');
      cookie(fresh); user = u;
    }
    if (cmd.action === 'state') {
      if (!token) await signIn(studentDemo);
      send(await snapshot(db, user)); return;
    }
    if (cmd.action === 'logout') { if (token) await db.execute({ sql: 'DELETE FROM sessions WHERE token=?', args: [hashToken(token)] }); cookie('signed-out'); send(await snapshot(db, null)); return; }
    if (cmd.action === 'demo') {
      if (cmd.role === 'admin' && process.env.PIRATE_ADMIN_PASSWORD) fail('Use the administrator password to sign in.', 401);
      await signIn(cmd.role === 'admin' ? adminDemo : studentDemo); send(await snapshot(db, user)); return;
    }
    if (cmd.action === 'signup' || cmd.action === 'login') {
      const email = String(cmd.email || '').trim().toLowerCase(), password = String(cmd.password || '');
      if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email) || email.length > 254 || password.length > 1024) fail('Enter a valid email and password.');
      let row = (await db.execute({ sql: 'SELECT * FROM accounts WHERE email=?', args: [email] })).rows[0];
      if (cmd.action === 'signup') {
        if (row) fail('This email already has an account. Please sign in.', 409);
        if (password.length < 8 || !cmd.name?.trim() || !cmd.level || !levels.includes(cmd.level)) fail('Enter your name, level, and a password of at least 8 characters.');
        const u: User = { id: randomUUID(), name: cmd.name.trim().slice(0, 60), email, role: 'student', level: cmd.level! };
        const salt = randomUUID(), hash = (await hashPassword(password, salt, 100000, 32, 'sha256')).toString('hex');
        await db.execute({ sql: 'INSERT INTO accounts VALUES(?,?,?,?,?)', args: [u.id, email, encode(u), salt, hash] });
        await signIn(u); send(await snapshot(db, user)); return;
      }
      // A pre-upgrade account can be claimed only by supplying its original password.
      const legacy = cmd.legacyAccount;
      if (!row && legacy?.email === email && legacy.role === 'student' && cmd.role === 'student' && /^[\da-f-]{36}$/i.test(legacy.id) && levels.includes(legacy.level) && typeof legacy.salt === 'string' && legacy.salt.length <= 128) {
        const check = (await hashPassword(password, legacy.salt, 100000, 32, 'sha256')).toString('hex');
        if (check === legacy.hash) {
          const u = profile({ ...legacy, demo: false });
          await db.execute({ sql: 'INSERT OR IGNORE INTO accounts VALUES(?,?,?,?,?)', args: [u.id, email, encode(u), legacy.salt, check] });
          row = (await db.execute({ sql: 'SELECT * FROM accounts WHERE email=?', args: [email] })).rows[0];
        }
      }
      const check = await hashPassword(password, String(row?.salt || 'missing-account'), 100000, 32, 'sha256');
      if (!row || !timingSafeEqual(check, Buffer.from(String(row.hash), 'hex')) || decode<User>(row.profile).role !== cmd.role) fail('The email or password is incorrect for this account type.', 401);
      await signIn(decode<User>(row.profile)); send(await snapshot(db, user)); return;
    }
    if (!user) return fail('Your session has expired. Please sign in again.', 401);
    const owner = user.id;
    if (cmd.action === 'paper' || cmd.action === 'delete-paper') {
      if (user.role !== 'admin') fail('Administrator access is required.', 403);
      if (cmd.action === 'paper') {
        const p = cmd.paper; if (!validPaper(p)) return fail('Invalid question paper.');
        await db.execute({ sql: 'INSERT INTO papers VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET published=excluded.published, data=excluded.data', args: [p.id, Number(p.published), Date.now(), encode(p)] });
      } else {
        if (!cmd.id?.startsWith('paper-')) fail('This paper cannot be removed.');
        await db.execute({ sql: 'DELETE FROM papers WHERE id=?', args: [cmd.id!] });
      }
    } else if (cmd.action === 'draft') {
      const d = cmd.draft; if (!d || user.role !== 'student' || d.userId !== owner || !Number.isFinite(d.startedAt)) return fail('Invalid test session.');
      const old = (await db.execute({ sql: 'SELECT data FROM drafts WHERE owner=?', args: [owner] })).rows[0];
      const previous = old ? decode<Draft>(old.data) : null;
      const record = previous?.startedAt === d.startedAt ? previous.paper : decode<Paper | null>((await db.execute({ sql: 'SELECT data FROM papers WHERE id=? AND published=1', args: [d.paper.id] })).rows[0]?.data ?? 'null');
      if (!record) return fail('This paper is no longer available.', 404);
      const saved = { ...d, paper: record, endsAt: d.startedAt + record.minutes * 60000 };
      await db.execute({ sql: 'INSERT INTO drafts(owner,data) SELECT ?,? WHERE NOT EXISTS(SELECT 1 FROM attempts WHERE id=?) ON CONFLICT(owner) DO UPDATE SET data=excluded.data', args: [owner, encode(saved), `result-${owner}-${d.startedAt}`] });
    } else if (cmd.action === 'submit') {
      const tx = await db.transaction('write');
      try {
        const old = (await tx.execute({ sql: 'SELECT data FROM attempts WHERE id=? AND owner=?', args: [cmd.id || '', owner] })).rows[0];
        if (old) { await tx.commit(); send({ attempt: decode<Attempt>(old.data) }); return; }
        const row = (await tx.execute({ sql: 'SELECT data FROM drafts WHERE owner=?', args: [owner] })).rows[0];
        if (!row || user.role !== 'student') fail('No active test was found.', 409);
        const draft = decode<Draft>(row.data), id = `result-${owner}-${draft.startedAt}`;
        if (cmd.id !== id) fail('This test was replaced by another attempt.', 409);
        const a = { ...gradeAttempt(draft, user, Math.min(Date.now(), draft.endsAt)), id };
        await tx.execute({ sql: 'INSERT INTO attempts VALUES(?,?,?,?)', args: [id, owner, a.finishedAt, encode(a)] });
        await tx.execute({ sql: 'DELETE FROM drafts WHERE owner=?', args: [owner] });
        await tx.commit(); send({ attempt: a }); return;
      } finally { tx.close(); }
    } else if (cmd.action === 'seen') {
      await db.execute({ sql: 'INSERT OR REPLACE INTO notices VALUES(?,1)', args: [owner] });
    } else if (cmd.action === 'migrate') {
      const rows: InStatement[] = [];
      for (const a of cmd.attempts || []) if (a.userId === owner && a.id && Number.isFinite(a.finishedAt) && Array.isArray(a.questions)) rows.push({ sql: 'INSERT OR IGNORE INTO attempts VALUES(?,?,?,?)', args: [a.id, owner, a.finishedAt, encode(a)] });
      if (cmd.draft?.userId === owner && validPaper(cmd.draft.paper)) rows.push({ sql: 'INSERT OR IGNORE INTO drafts VALUES(?,?)', args: [owner, encode(cmd.draft)] });
      if (cmd.seen) rows.push({ sql: 'INSERT OR IGNORE INTO notices VALUES(?,1)', args: [owner] });
      if (user.role === 'admin') for (const p of cmd.papers || []) if (validPaper(p)) {
        const baseline = builtInPapers.find(b => b.id === p.id);
        rows.push({ sql: 'INSERT INTO papers VALUES(?,?,?,?) ON CONFLICT(id) DO UPDATE SET data=excluded.data,published=excluded.published WHERE papers.data=?', args: [p.id, Number(p.published), Date.now(), encode(p), baseline ? encode(baseline) : ''] });
      }
      if (rows.length) await db.batch(rows, 'write');
    } else return fail('Unknown persistence operation.');
    send({ ok: true });
  } catch (error) {
    res.statusCode = error instanceof RequestError ? error.status : 503;
    if (!(error instanceof RequestError)) console.error('Database request failed:', error instanceof Error ? error.name : 'DatabaseError');
    send({ error: error instanceof RequestError ? error.message : 'The database could not save or load your data. Please try again.' });
  }
}
